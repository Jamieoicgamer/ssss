
import React, { useState } from 'react';
import { useGame } from '@/context/GameContext';
import { Users, Heart, Sword, Eye, Wrench, MessageCircle, Radio, Clock, Package, ArrowRight } from 'lucide-react';

export const SquadManagement = () => {
  const { gameState, equipItem, useConsumable, startRecruitment, getModuleDetails, transferItemToSquad } = useGame();
  const [selectedMember, setSelectedMember] = useState<string | null>(null);

  const recruitmentModule = getModuleDetails('recruitment-radio');
  const canRecruit = recruitmentModule?.isActive && gameState.recruitmentCooldown <= Date.now();
  const isRecruiting = recruitmentModule?.recruitmentActive;
  
  const formatTime = (timestamp: number) => {
    const timeLeft = Math.max(0, timestamp - Date.now());
    const minutes = Math.floor(timeLeft / 60000);
    const seconds = Math.floor((timeLeft % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getStatIcon = (stat: string) => {
    switch (stat) {
      case 'combat': return <Sword size={16} className="text-red-400" />;
      case 'stealth': return <Eye size={16} className="text-purple-400" />;
      case 'tech': return <Wrench size={16} className="text-blue-400" />;
      case 'charisma': return <MessageCircle size={16} className="text-green-400" />;
      default: return <Heart size={16} className="text-pink-400" />;
    }
  };

  const getSpecializationColor = (specialization: string) => {
    switch (specialization) {
      case 'combat': return 'text-red-400';
      case 'stealth': return 'text-purple-400';
      case 'tech': return 'text-blue-400';
      case 'medic': return 'text-green-400';
      case 'scavenger': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'text-green-400';
      case 'mission': return 'text-blue-400';
      case 'injured': return 'text-red-400';
      case 'recruiting': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const handleRecruit = () => {
    if (canRecruit) {
      startRecruitment();
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-blue-500/20">
        <h2 className="text-xl font-bold text-blue-400 mb-2">Squad Management</h2>
        <p className="text-gray-400 text-sm">Manage your operatives and equipment</p>
      </div>

      {/* Recruitment Section */}
      <div className="bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-amber-500/20">
        <h3 className="text-lg font-semibold text-amber-400 mb-3 flex items-center">
          <Radio className="mr-2" size={20} />
          Recruitment Radio
        </h3>
        
        {!recruitmentModule?.isActive ? (
          <p className="text-red-400 text-sm">Recruitment Radio module is not active</p>
        ) : isRecruiting ? (
          <div className="text-yellow-400">
            <p className="text-sm mb-2">Broadcasting recruitment signal...</p>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-yellow-500 h-2 rounded-full animate-pulse" style={{ width: '60%' }} />
            </div>
            <p className="text-xs mt-1">Estimated completion: 5 minutes</p>
          </div>
        ) : gameState.recruitmentCooldown > Date.now() ? (
          <div className="text-gray-400">
            <p className="text-sm">Recruitment on cooldown</p>
            <p className="text-xs">Time remaining: {formatTime(gameState.recruitmentCooldown)}</p>
          </div>
        ) : (
          <div>
            <p className="text-gray-400 text-sm mb-3">
              Broadcast a recruitment signal to attract new operatives. 
              Cost: {150 + (gameState.squad.length * 50)} caps
            </p>
            <button
              onClick={handleRecruit}
              disabled={!canRecruit || gameState.caps < (150 + (gameState.squad.length * 50))}
              className="bg-amber-600 hover:bg-amber-500 disabled:bg-gray-600 disabled:cursor-not-allowed px-4 py-2 rounded-lg text-white font-medium transition-all"
            >
              Start Recruitment
            </button>
          </div>
        )}
      </div>

      {/* Squad Overview */}
      <div className="bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-gray-500/20">
        <h3 className="text-white font-semibold mb-3">Squad Overview</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-400">{gameState.squad.length}</p>
            <p className="text-sm text-gray-400">Active Members</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-green-400">{gameState.maxSquadSize}</p>
            <p className="text-sm text-gray-400">Max Capacity</p>
          </div>
        </div>
      </div>

      {/* Squad Members */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-amber-400">Squad Members</h3>
        {gameState.squad.map((member) => (
          <div
            key={member.id}
            onClick={() => setSelectedMember(selectedMember === member.id ? null : member.id)}
            className={`bg-black/40 backdrop-blur-sm rounded-xl p-4 border-2 cursor-pointer transition-all hover-scale ${
              selectedMember === member.id
                ? 'border-blue-500 bg-blue-500/10'
                : 'border-gray-500/20 hover:border-gray-400'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="text-white font-semibold">{member.name}</h4>
                <p className={`text-sm ${getSpecializationColor(member.specialization)}`}>
                  Level {member.level} • {member.specialization}
                </p>
              </div>
              <div className="text-right">
                <div className={`flex items-center space-x-1 ${getStatusColor(member.status)}`}>
                  <div className={`w-2 h-2 rounded-full ${
                    member.status === 'available' ? 'bg-green-500' :
                    member.status === 'mission' ? 'bg-blue-500' :
                    member.status === 'injured' ? 'bg-red-500' : 'bg-yellow-500'
                  }`}></div>
                  <span className="text-xs capitalize">{member.status}</span>
                </div>
              </div>
            </div>

            {/* Health Bar */}
            <div className="mb-3">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-gray-400">Health</span>
                <span className="text-red-400">{member.stats.health}/{member.stats.maxHealth}</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-red-500 h-2 rounded-full transition-all"
                  style={{ width: `${(member.stats.health / member.stats.maxHealth) * 100}%` }}
                />
              </div>
            </div>

            {/* Hunger & Thirst Bars */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-gray-400">🍞 Hunger</span>
                  <span className="text-green-400">{Math.floor(member.stats.hunger)}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-1">
                  <div 
                    className="bg-green-500 h-1 rounded-full transition-all"
                    style={{ width: `${member.stats.hunger}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-gray-400">💧 Thirst</span>
                  <span className="text-blue-400">{Math.floor(member.stats.thirst)}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-1">
                  <div 
                    className="bg-blue-500 h-1 rounded-full transition-all"
                    style={{ width: `${member.stats.thirst}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Expanded Details */}
            {selectedMember === member.id && (
              <div className="space-y-3 animate-fade-in">
                {/* Stats */}
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(member.stats).filter(([key]) => 
                    !['health', 'maxHealth', 'hunger', 'thirst'].includes(key)
                  ).map(([stat, value]) => (
                    <div key={stat} className="flex items-center space-x-2 bg-black/20 rounded-lg p-2">
                      {getStatIcon(stat)}
                      <span className="text-gray-400 text-sm capitalize">{stat}:</span>
                      <span className="text-white font-bold">{value}</span>
                    </div>
                  ))}
                </div>

                {/* Equipment Slots */}
                <div className="space-y-2">
                  <h5 className="text-white font-medium">Equipment</h5>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-black/20 rounded-lg p-2">
                      <p className="text-gray-400 text-xs">Weapon</p>
                      <p className="text-white text-sm">{member.equipment.weapon || 'None'}</p>
                    </div>
                    <div className="bg-black/20 rounded-lg p-2">
                      <p className="text-gray-400 text-xs">Armor</p>
                      <p className="text-white text-sm">{member.equipment.armor || 'None'}</p>
                    </div>
                    <div className="bg-black/20 rounded-lg p-2">
                      <p className="text-gray-400 text-xs">Accessory</p>
                      <p className="text-white text-sm">{member.equipment.accessory || 'None'}</p>
                    </div>
                  </div>
                </div>

                {/* Personal Inventory */}
                <div className="space-y-2">
                  <h5 className="text-white font-medium flex items-center">
                    <Package className="mr-2" size={16} />
                    Personal Inventory ({member.inventory.length})
                  </h5>
                  {member.inventory.length === 0 ? (
                    <p className="text-gray-400 text-sm">No personal items</p>
                  ) : (
                    <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                      {member.inventory.map((item, index) => (
                        <div key={`${item.id}-${index}`} className="bg-black/20 rounded-lg p-2">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{item.icon}</span>
                            <div className="flex-1 min-w-0">
                              <p className="text-white text-xs font-medium truncate">{item.name}</p>
                              <p className="text-gray-400 text-xs">x{item.quantity}</p>
                            </div>
                          </div>
                          
                          {(item.type === 'weapon' || item.type === 'armor') && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const slot = item.type === 'weapon' ? 'weapon' : 'armor';
                                equipItem(member.id, item.id, slot);
                              }}
                              className="w-full mt-1 bg-purple-600 hover:bg-purple-500 px-2 py-1 rounded text-white text-xs transition-all"
                            >
                              Equip
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Transfer Items from Main Inventory */}
                <div className="bg-amber-900/20 p-3 rounded-lg border border-amber-500/30">
                  <h5 className="text-amber-400 font-medium mb-2 flex items-center">
                    <ArrowRight className="mr-2" size={16} />
                    Transfer Items
                  </h5>
                  <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">
                    {gameState.inventory.filter(item => item.quantity > 0).slice(0, 6).map(item => (
                      <button
                        key={item.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          transferItemToSquad(item.id, member.id, 1);
                        }}
                        className="bg-amber-600 hover:bg-amber-500 p-2 rounded text-white text-xs transition-all text-left"
                      >
                        <div className="flex items-center space-x-1">
                          <span>{item.icon}</span>
                          <span className="truncate">{item.name}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Traits */}
                {member.traits && member.traits.length > 0 && (
                  <div>
                    <h5 className="text-white font-medium mb-2">Traits</h5>
                    <div className="flex flex-wrap gap-1">
                      {member.traits.map((trait, index) => (
                        <span
                          key={index}
                          className="bg-purple-500/20 text-purple-400 text-xs px-2 py-1 rounded-full"
                        >
                          {trait}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Actions */}
                {member.status === 'available' && (
                  <div className="flex space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        useConsumable('stimpak', member.id);
                      }}
                      disabled={member.stats.health >= member.stats.maxHealth}
                      className="bg-green-600 hover:bg-green-500 disabled:bg-gray-600 disabled:cursor-not-allowed px-3 py-1 rounded-lg text-white text-sm font-medium transition-all"
                    >
                      Use Stimpak
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {gameState.squad.length === 0 && (
        <div className="text-center py-8">
          <Users className="mx-auto text-gray-400 mb-2" size={48} />
          <p className="text-gray-400">No squad members</p>
          <p className="text-gray-500 text-sm">Use the recruitment radio to find operatives</p>
        </div>
      )}
    </div>
  );
};
