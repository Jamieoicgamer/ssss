import React, { useState, useEffect } from 'react';
import { useGame } from '@/context/GameContext';
import { Sword, Users, Target, Clock, Trophy, AlertTriangle, Star } from 'lucide-react';
import { COMBAT_TARGETS, CombatTarget } from './CombatTargets';

export const Combat = () => {
  const { gameState, startMission, addCurrency, addExperience, addItem, useChem, addNotification } = useGame();
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [selectedSquad, setSelectedSquad] = useState<string[]>([]);
  const [combatResult, setCombatResult] = useState<any>(null);
  const [appliedChems, setAppliedChems] = useState<{ [squadId: string]: string[] }>({});

  const availableSquad = gameState.squad.filter(member => member.status === 'available');
  const availableTargets = COMBAT_TARGETS.filter(target => gameState.commanderLevel >= target.unlockLevel);

  const calculateWinChance = () => {
    if (!selectedTarget || selectedSquad.length === 0) return 0;
    
    const target = availableTargets.find(t => t.id === selectedTarget);
    if (!target) return 0;

    const squadMembers = gameState.squad.filter(member => selectedSquad.includes(member.id));
    let totalCombat = squadMembers.reduce((sum, member) => sum + member.stats.combat, 0);
    const avgLevel = squadMembers.reduce((sum, member) => sum + member.level, 0) / squadMembers.length;
    
    // Apply chem bonuses
    squadMembers.forEach(member => {
      const memberChems = appliedChems[member.id] || [];
      memberChems.forEach(chemId => {
        const chem = gameState.inventory.find(item => item.id === chemId);
        if (chem?.effects?.damage) {
          totalCombat += chem.effects.damage;
        }
      });
    });
    
    const baseChance = Math.min(95, Math.max(5, 
      (totalCombat * 2) + (avgLevel * 5) - (target.difficulty * 8) + 30
    ));
    
    return Math.round(baseChance);
  };

  const canStartCombat = () => {
    if (!selectedTarget || selectedSquad.length === 0) return false;
    const target = availableTargets.find(t => t.id === selectedTarget);
    if (!target) return false;
    
    const combatCooldown = gameState.combatCooldowns?.[selectedTarget] || 0;
    const canFight = combatCooldown < Date.now();
    
    return gameState.commanderLevel >= target.minLevel && 
           selectedSquad.length >= target.minSquadSize &&
           canFight;
  };

  const applyChem = (squadMemberId: string, chemId: string) => {
    const chem = gameState.inventory.find(item => item.id === chemId);
    if (chem && chem.type === 'chem' && chem.quantity > 0) {
      setAppliedChems(prev => ({
        ...prev,
        [squadMemberId]: [...(prev[squadMemberId] || []), chemId]
      }));
      useChem(chemId, squadMemberId);
    }
  };

  const startCombat = () => {
    if (!canStartCombat()) {
      // Send notification about why combat can't start
      const target = availableTargets.find(t => t.id === selectedTarget);
      if (!target) {
        addNotification({
          id: `combat-error-${Date.now()}`,
          type: 'error',
          title: 'Combat Failed',
          message: 'Invalid target selected',
          priority: 'high'
        });
        return;
      }

      let reason = '';
      if (gameState.commanderLevel < target.minLevel) {
        reason = `Commander level ${target.minLevel} required (current: ${gameState.commanderLevel})`;
      } else if (selectedSquad.length < target.minSquadSize) {
        reason = `Minimum ${target.minSquadSize} squad members required (selected: ${selectedSquad.length})`;
      } else {
        const combatCooldown = gameState.combatCooldowns?.[selectedTarget] || 0;
        if (combatCooldown >= Date.now()) {
          const timeLeft = Math.ceil((combatCooldown - Date.now()) / 60000);
          reason = `Combat on cooldown for ${timeLeft} more minutes`;
        }
      }

      addNotification({
        id: `combat-error-${Date.now()}`,
        type: 'error',
        title: 'Combat Requirements Not Met',
        message: reason,
        priority: 'high'
      });
      return;
    }

    const target = availableTargets.find(t => t.id === selectedTarget);
    if (!target) return;

    const mission = {
      id: `combat-${target.id}-${Date.now()}`,
      title: `Combat: ${target.name}`,
      type: 'combat' as const,
      difficulty: target.difficulty,
      requirements: { level: target.minLevel, squadSize: target.minSquadSize },
      rewards: target.rewards,
      duration: Math.max(2, target.difficulty),
      description: target.description,
      location: target.location,
      assignedSquad: selectedSquad
    };

    const missionStarted = startMission(mission.id, selectedSquad);
    
    if (missionStarted) {
      // Set combat cooldown
      const cooldownMinutes = Math.max(5, target.difficulty * 2);
      
      addNotification({
        id: `combat-start-${Date.now()}`,
        type: 'success',
        title: 'Combat Mission Started',
        message: `Squad deployed to engage ${target.name}`,
        priority: 'medium'
      });

      setSelectedTarget(null);
      setSelectedSquad([]);
      setAppliedChems({});
    }
  };

  const formatTime = (timestamp: number) => {
    const timeLeft = Math.max(0, timestamp - Date.now());
    const minutes = Math.floor(timeLeft / 60000);
    const seconds = Math.floor((timeLeft % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getDifficultyColor = (difficulty: number) => {
    if (difficulty <= 3) return 'text-green-400';
    if (difficulty <= 6) return 'text-yellow-400';
    if (difficulty <= 9) return 'text-orange-400';
    return 'text-red-400';
  };

  const getTargetTypeIcon = (type: string) => {
    switch (type) {
      case 'raider': return '🏴‍☠️';
      case 'mutant': return '🧟';
      case 'robot': return '🤖';
      case 'creature': return '🦎';
      case 'faction': return '⚔️';
      case 'legendary': return '👑';
      default: return '💀';
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-red-500/20">
        <h2 className="text-xl font-bold text-red-400 mb-2">Combat Operations</h2>
        <p className="text-gray-400 text-sm">Deploy your squad against hostile factions across the wasteland</p>
        <div className="mt-2 flex items-center space-x-4 text-sm">
          <span className="text-amber-400">Available Targets: {availableTargets.length}</span>
          <span className="text-blue-400">Squad Ready: {availableSquad.length}</span>
        </div>
      </div>

      {/* Combat Result */}
      {combatResult && (
        <div className={`bg-black/40 backdrop-blur-sm rounded-xl p-4 border-2 animate-fade-in ${
          combatResult.success ? 'border-green-500' : 'border-red-500'
        }`}>
          <h3 className={`font-bold mb-2 flex items-center ${combatResult.success ? 'text-green-400' : 'text-red-400'}`}>
            {combatResult.success ? <Trophy className="mr-2" size={20} /> : <AlertTriangle className="mr-2" size={20} />}
            {combatResult.success ? 'Victory!' : 'Mission Failed!'}
          </h3>
          <p className="text-gray-300 mb-2">Combat against {combatResult.target}</p>
          
          <div className="space-y-2">
            <div className="text-sm text-gray-400">
              <strong>Rewards:</strong> {combatResult.rewards.caps} caps
              {combatResult.rewards.scrip && `, ${combatResult.rewards.scrip} scrip`}
              {combatResult.rewards.experience && `, ${combatResult.rewards.experience} XP`}
            </div>
            
            {combatResult.loot.length > 0 && (
              <div className="text-sm text-green-400">
                <strong>Loot:</strong> {combatResult.loot.join(', ')}
              </div>
            )}
            
            {combatResult.casualties.length > 0 && (
              <div className="text-sm text-red-400">
                <strong>Casualties:</strong> {combatResult.casualties.join(', ')}
              </div>
            )}
          </div>
          
          <button 
            onClick={() => setCombatResult(null)}
            className="mt-3 bg-gray-600 hover:bg-gray-500 px-4 py-2 rounded-lg text-white text-sm transition-all"
          >
            Continue
          </button>
        </div>
      )}

      {/* Target Selection */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-amber-400 flex items-center">
          <Target className="mr-2" size={20} />
          Combat Targets ({availableTargets.length} Available)
        </h3>
        
        <div className="grid gap-3">
          {availableTargets.map((target) => {
            const isOnCooldown = (gameState.combatCooldowns?.[target.id] || 0) > Date.now();
            const cooldownTime = gameState.combatCooldowns?.[target.id] || 0;
            
            return (
              <div
                key={target.id}
                onClick={() => !isOnCooldown && setSelectedTarget(target.id)}
                className={`bg-black/40 backdrop-blur-sm rounded-xl p-4 border-2 transition-all hover-scale ${
                  isOnCooldown 
                    ? 'border-gray-500/20 opacity-50 cursor-not-allowed'
                    : selectedTarget === target.id 
                      ? 'border-red-500 bg-red-500/10 cursor-pointer' 
                      : 'border-gray-500/20 hover:border-gray-400 cursor-pointer'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl">{getTargetTypeIcon(target.type)}</span>
                    <div>
                      <h4 className="text-white font-semibold">{target.name}</h4>
                      <p className="text-xs text-gray-400">{target.faction} • {target.location}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end space-y-1">
                    <span className={`text-xs px-2 py-1 rounded-full ${getDifficultyColor(target.difficulty)} bg-current/20`}>
                      Difficulty {target.difficulty}
                    </span>
                    {target.type === 'legendary' && (
                      <span className="text-xs bg-purple-500/20 text-purple-400 px-2 py-1 rounded-full flex items-center">
                        <Star size={12} className="mr-1" />
                        Legendary
                      </span>
                    )}
                  </div>
                </div>
                
                {isOnCooldown && (
                  <div className="text-red-400 text-sm mb-2 flex items-center">
                    <Clock size={16} className="mr-1" />
                    Cooldown: {formatTime(cooldownTime)}
                  </div>
                )}
                
                <p className="text-gray-400 text-sm mb-3">{target.description}</p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400 text-xs">Requirements</p>
                    <p className="text-white">Level {target.minLevel} • {target.minSquadSize} Squad • {target.enemyCount} Enemies</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-xs">Rewards</p>
                    <div className="flex space-x-2">
                      <span className="text-yellow-400">{target.rewards.caps}💰</span>
                      {target.rewards.scrip && <span className="text-blue-400">{target.rewards.scrip}🔧</span>}
                      <span className="text-purple-400">{target.rewards.experience}XP</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Squad Selection */}
      {selectedTarget && (
        <div className="space-y-3 animate-fade-in">
          <h3 className="text-lg font-semibold text-amber-400 flex items-center">
            <Users className="mr-2" size={20} />
            Select Squad Members
          </h3>
          
          {availableSquad.map((member) => (
            <div
              key={member.id}
              className={`bg-black/40 backdrop-blur-sm rounded-xl p-4 border-2 transition-all ${
                selectedSquad.includes(member.id)
                  ? 'border-green-500 bg-green-500/10'
                  : 'border-gray-500/20 hover:border-gray-400'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setSelectedSquad(prev => 
                      prev.includes(member.id) 
                        ? prev.filter(id => id !== member.id)
                        : [...prev, member.id]
                    )}
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      selectedSquad.includes(member.id)
                        ? 'border-green-500 bg-green-500'
                        : 'border-gray-500'
                    }`}
                  >
                    {selectedSquad.includes(member.id) && <span className="text-white text-xs">✓</span>}
                  </button>
                  
                  <div>
                    <h4 className="text-white font-medium">{member.name}</h4>
                    <p className="text-sm text-gray-400">
                      Lv.{member.level} • Combat: {member.stats.combat} • {member.specialization}
                    </p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="flex items-center space-x-1 mb-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-xs text-green-400">Available</span>
                  </div>
                  <div className="text-xs text-gray-400">
                    HP: {member.stats.health}/{member.stats.maxHealth}
                  </div>
                </div>
              </div>

              {/* Chem Application */}
              {selectedSquad.includes(member.id) && (
                <div className="border-t border-gray-500/20 pt-3">
                  <p className="text-sm text-gray-400 mb-2">Apply Chems:</p>
                  <div className="flex flex-wrap gap-2">
                    {gameState.inventory
                      .filter(item => item.type === 'chem' && item.quantity > 0)
                      .map(chem => (
                        <button
                          key={chem.id}
                          onClick={() => applyChem(member.id, chem.id)}
                          disabled={appliedChems[member.id]?.includes(chem.id)}
                          className="text-xs bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600 disabled:cursor-not-allowed px-2 py-1 rounded text-white transition-all"
                          title={chem.function}
                        >
                          {chem.icon} {chem.name}
                        </button>
                      ))
                    }
                  </div>
                  
                  {appliedChems[member.id]?.length > 0 && (
                    <div className="mt-2 text-xs text-purple-400">
                      Active: {appliedChems[member.id].map(chemId => {
                        const chem = gameState.inventory.find(item => item.id === chemId);
                        return chem?.name;
                      }).join(', ')}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Combat Initiation */}
      {selectedTarget && selectedSquad.length > 0 && (
        <div className="bg-black/20 rounded-xl p-4 animate-fade-in">
          <div className="flex items-center justify-between mb-3">
            <span className="text-gray-400">Win Probability:</span>
            <span className={`font-bold text-lg ${
              calculateWinChance() >= 70 ? 'text-green-400' : 
              calculateWinChance() >= 40 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {calculateWinChance()}%
            </span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
            <div>
              <p className="text-gray-400">Squad Combat Power</p>
              <p className="text-white font-semibold">
                {gameState.squad
                  .filter(member => selectedSquad.includes(member.id))
                  .reduce((sum, member) => sum + member.stats.combat, 0)}
              </p>
            </div>
            <div>
              <p className="text-gray-400">Estimated Duration</p>
              <p className="text-white font-semibold">
                {availableTargets.find(t => t.id === selectedTarget)?.difficulty || 0} minutes
              </p>
            </div>
          </div>
          
          <button
            onClick={startCombat}
            disabled={!canStartCombat()}
            className="w-full bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed p-4 rounded-lg text-white font-bold transition-all flex items-center justify-center space-x-2"
          >
            <Sword size={20} />
            <span>{canStartCombat() ? 'Engage in Combat' : 'Cannot Start Combat'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
