
import React, { useState } from 'react';
import { useGame } from '@/context/GameContext';
import { Radio, Clock, MapPin, Users, Star, ChevronRight, AlertTriangle } from 'lucide-react';

export const Operations = () => {
  const { gameState, startMission, handleEventChoice } = useGame();
  const [selectedMission, setSelectedMission] = useState<string | null>(null);
  const [selectedSquad, setSelectedSquad] = useState<string[]>([]);

  // Sandy Shores Main Quest Line - 15 Operations
  const sandyShoresQuests = [
    {
      id: 'ss-01-arrival',
      title: 'Arrival at Sandy Shores',
      type: 'main',
      difficulty: 1,
      requirements: { level: 0, squadSize: 1 },
      rewards: { caps: 50, experience: 25 },
      duration: 10,
      description: 'Establish your first foothold in the Sandy Shores region. Scout the immediate area and set up basic communications.',
      location: 'Sandy Shores Outskirts'
    },
    {
      id: 'ss-02-radio-silence',
      title: 'Radio Silence',
      type: 'main',
      difficulty: 2,
      requirements: { level: 1, squadSize: 1 },
      rewards: { caps: 75, techFrags: 3, experience: 35 },
      duration: 15,
      description: 'Investigate why the local radio tower has gone dark. The last transmission mentioned "strange signals from the east."',
      location: 'Communication Tower Alpha'
    },
    {
      id: 'ss-03-first-contact',
      title: 'First Contact',
      type: 'main',
      difficulty: 2,
      requirements: { level: 1, squadSize: 2 },
      rewards: { caps: 100, experience: 40 },
      duration: 20,
      description: 'Make contact with the Sandy Shores Trading Post. The locals seem nervous about something in the ruins.',
      location: 'Sandy Shores Trading Post'
    },
    {
      id: 'ss-04-ghoul-problem',
      title: 'The Ghoul Problem',
      type: 'main',
      difficulty: 3,
      requirements: { level: 2, squadSize: 2 },
      rewards: { caps: 150, scrip: 5, experience: 50 },
      duration: 25,
      description: 'Clear the feral ghouls from the old shopping district. Traders report strange behavior - they seem organized.',
      location: 'Sandy Shores Shopping District'
    },
    {
      id: 'ss-05-vault-door',
      title: 'The Sealed Vault Door',
      type: 'main',
      difficulty: 3,
      requirements: { level: 2, squadSize: 2, skills: ['tech'] },
      rewards: { caps: 200, techFrags: 8, experience: 60 },
      duration: 30,
      description: 'Investigate Vault 47. The door is sealed, but strange energy readings suggest something is still active inside.',
      location: 'Vault 47 Entrance'
    }
  ];

  const randomEvents = gameState.activeEvents || [];
  const activeMissions = gameState.activeMissions || [];
  const availableSquad = gameState.squad.filter(member => member.status === 'available');

  const startSelectedMission = () => {
    if (!selectedMission || selectedSquad.length === 0) return;

    const mission = sandyShoresQuests.find(m => m.id === selectedMission);
    if (!mission) return;

    // Call startMission with the mission ID and selected squad member IDs
    startMission(selectedMission, selectedSquad);
    setSelectedMission(null);
    setSelectedSquad([]);
  };

  const toggleSquadMember = (memberId: string) => {
    setSelectedSquad(prev => 
      prev.includes(memberId) 
        ? prev.filter(id => id !== memberId)
        : [...prev, memberId]
    );
  };

  const canStartMission = (mission: any) => {
    return gameState.commanderLevel >= mission.requirements.level &&
           availableSquad.length >= mission.requirements.squadSize;
  };

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-amber-500/20">
        <h2 className="text-xl font-bold text-amber-400 mb-2">Operations Command</h2>
        <p className="text-gray-400 text-sm">Manage missions, quests, and ongoing operations</p>
      </div>

      {/* Random Events */}
      {randomEvents.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-red-400">⚠️ Active Events</h3>
          {randomEvents.map((event, index) => (
            <div key={event.id} className="bg-red-900/20 backdrop-blur-sm rounded-xl p-4 border border-red-500/30">
              <h4 className="text-white font-semibold mb-2">{event.title}</h4>
              <p className="text-gray-300 text-sm mb-3">{event.description}</p>
              <div className="space-y-2">
                {event.choices.map((choice, choiceIndex) => (
                  <button
                    key={choiceIndex}
                    onClick={() => handleEventChoice(event.id, choiceIndex)}
                    className="w-full bg-red-600 hover:bg-red-500 p-2 rounded-lg text-white text-sm font-medium transition-all text-left"
                  >
                    {choice.text}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Active Missions Status */}
      {activeMissions.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-blue-400">🎯 Active Operations</h3>
          {activeMissions.map((mission) => {
            const timeLeft = Math.max(0, mission.duration * 60000 - (Date.now() - mission.startTime));
            const progress = Math.min(100, ((Date.now() - mission.startTime) / (mission.duration * 60000)) * 100);
            
            return (
              <div key={mission.id} className="bg-blue-900/20 backdrop-blur-sm rounded-xl p-4 border border-blue-500/30">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-white font-semibold">{mission.title}</h4>
                  <span className="text-blue-400 text-sm">
                    {Math.ceil(timeLeft / 60000)}m remaining
                  </span>
                </div>
                
                <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full transition-all"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Squad: {mission.assignedSquad.length} operatives</span>
                  <span className="text-gray-400">{mission.location}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Sandy Shores Main Quest Line */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-amber-400">📖 Sandy Shores Campaign</h3>
        {sandyShoresQuests.map((mission, index) => {
          const isAvailable = canStartMission(mission);
          const isLocked = index > 0 && !gameState.completedMissions.includes(sandyShoresQuests[index - 1].id);
          const isCompleted = gameState.completedMissions.includes(mission.id);
          
          return (
            <div
              key={mission.id}
              onClick={() => isAvailable && !isLocked && !isCompleted ? setSelectedMission(mission.id) : null}
              className={`bg-black/40 backdrop-blur-sm rounded-xl p-4 border-2 transition-all ${
                isCompleted 
                  ? 'border-green-500/30 bg-green-500/5'
                  : isLocked 
                    ? 'border-gray-500/20 bg-gray-500/5 cursor-not-allowed opacity-50'
                    : selectedMission === mission.id
                      ? 'border-amber-500 bg-amber-500/10 cursor-pointer'
                      : isAvailable
                        ? 'border-gray-500/20 hover:border-gray-400 cursor-pointer'
                        : 'border-red-500/30 bg-red-500/5 cursor-not-allowed opacity-75'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-white font-semibold flex items-center">
                  {isCompleted && <span className="text-green-400 mr-2">✓</span>}
                  {isLocked && <span className="text-gray-400 mr-2">🔒</span>}
                  {mission.title}
                </h4>
                <div className="flex items-center space-x-2">
                  <span className="text-xs bg-amber-500/20 text-amber-400 px-2 py-1 rounded-full">
                    Level {mission.requirements.level}
                  </span>
                  <span className="text-xs bg-blue-500/20 text-blue-400 px-2 py-1 rounded-full">
                    {mission.duration}m
                  </span>
                </div>
              </div>
              
              <p className="text-gray-400 text-sm mb-2">{mission.description}</p>
              
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-3">
                  <span className="text-yellow-400">{mission.rewards.caps} 💰</span>
                  {mission.rewards.scrip && <span className="text-blue-400">{mission.rewards.scrip} 🔧</span>}
                  {mission.rewards.techFrags && <span className="text-purple-400">{mission.rewards.techFrags} ⚙️</span>}
                  <span className="text-green-400">{mission.rewards.experience} XP</span>
                </div>
                <span className="text-gray-400">{mission.location}</span>
              </div>
              
              {!isAvailable && !isLocked && !isCompleted && (
                <p className="text-red-400 text-xs mt-2">
                  Requires: Level {mission.requirements.level}, {mission.requirements.squadSize} squad members
                </p>
              )}
            </div>
          );
        })}
      </div>

      {/* Squad Selection for Selected Mission */}
      {selectedMission && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-amber-400">Select Squad</h3>
          {availableSquad.map((member) => (
            <div
              key={member.id}
              onClick={() => toggleSquadMember(member.id)}
              className={`bg-black/40 backdrop-blur-sm rounded-xl p-3 border-2 cursor-pointer transition-all ${
                selectedSquad.includes(member.id)
                  ? 'border-green-500 bg-green-500/10'
                  : 'border-gray-500/20 hover:border-gray-400'
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-white font-medium">{member.name}</h4>
                  <p className="text-sm text-gray-400">Level {member.level} • {member.specialization}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-xs text-green-400">Available</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {selectedSquad.length > 0 && (
            <button
              onClick={startSelectedMission}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 p-3 rounded-lg text-white font-bold hover:from-amber-500 hover:to-orange-500 transition-all"
            >
              Deploy Squad
            </button>
          )}
        </div>
      )}
    </div>
  );
};
