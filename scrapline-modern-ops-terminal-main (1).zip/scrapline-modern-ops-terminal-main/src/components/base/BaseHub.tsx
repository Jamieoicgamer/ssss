import React, { useState } from 'react';
import { useGame } from '@/context/GameContext';
import { Zap, Shield, Wrench, Radio, Brain, Users, ArrowUp, Heart, Package, Home, Wifi, Settings } from 'lucide-react';
import { PowerManagement } from './PowerManagement';

export const BaseHub = () => {
  const { gameState, toggleModule, upgradeModule, startRecruitment, getModuleDetails } = useGame();
  const [selectedModule, setSelectedModule] = useState<string | null>(null);
  const [showPowerManagement, setShowPowerManagement] = useState(false);

  const getModuleIcon = (type: string) => {
    switch (type) {
      case 'power': return Zap;
      case 'defense': return Shield;
      case 'workshop': return Wrench;
      case 'comms': return Radio;
      case 'intel': return Brain;
      case 'squad': return Users;
      case 'medical': return Heart;
      case 'storage': return Package;
      case 'barracks': return Home;
      case 'recruitment': return Wifi;
      default: return Zap;
    }
  };

  const getModuleColor = (type: string) => {
    switch (type) {
      case 'power': return 'from-yellow-500 to-orange-500';
      case 'defense': return 'from-red-500 to-pink-500';
      case 'workshop': return 'from-blue-500 to-cyan-500';
      case 'comms': return 'from-green-500 to-emerald-500';
      case 'intel': return 'from-purple-500 to-violet-500';
      case 'squad': return 'from-amber-500 to-yellow-500';
      case 'medical': return 'from-pink-500 to-red-500';
      case 'storage': return 'from-gray-500 to-slate-500';
      case 'barracks': return 'from-indigo-500 to-blue-500';
      case 'recruitment': return 'from-emerald-500 to-teal-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getModuleDescription = (module: any) => {
    const baseDescriptions: { [key: string]: string } = {
      'fusion-core': `Power output: ${module.level * 25}kW - Base energy capacity`,
      'squad-room': `Squad capacity: ${4 + module.level * 2} operatives`,
      'comms': `Mission access tier ${module.level} - Faction communications`,
      'defense': 'PvP protection and early warning systems',
      'workshop': 'Crafting and weapon modification station',
      'intel': 'Advanced mission intelligence and threat analysis',
      'medical-bay': `Healing speed: ${module.level * 25}% faster recovery`,
      'storage-room': `Storage capacity: +${module.capacity || 50} units`,
      'barracks': `Morale boost: +${module.level * 10}% squad efficiency`,
      'recruitment-radio': 'Broadcasts recruitment signals across the wasteland'
    };
    return baseDescriptions[module.id] || module.description || 'Base module functionality';
  };

  const handleRecruitment = () => {
    const success = startRecruitment();
    if (!success) {
      alert('Cannot recruit: Not enough caps, recruitment on cooldown, or radio offline');
    }
  };

  const isRecruitmentAvailable = () => {
    const recruitModule = gameState.baseModules.find(m => m.id === 'recruitment-radio');
    return recruitModule?.isActive && gameState.recruitmentCooldown <= Date.now();
  };

  const getRecruitmentCooldown = () => {
    const timeLeft = Math.max(0, gameState.recruitmentCooldown - Date.now());
    return Math.ceil(timeLeft / (60 * 1000));
  };

  // Calculate power efficiency
  const activeCores = gameState.fusionCores.filter(core => core.isActive && core.currentCharge > 0);
  const totalPowerGeneration = activeCores.reduce((sum, core) => sum + (core.efficiency / 10), 0);
  const totalPowerConsumption = gameState.baseModules
    .filter(module => module.isActive)
    .reduce((sum, module) => sum + module.energyCost, 0);
  const powerEfficiency = totalPowerConsumption > 0 
    ? Math.min(100, (totalPowerGeneration / totalPowerConsumption) * 100)
    : 100;

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div 
        className="text-center mb-6 p-6 rounded-xl border border-amber-500/20 relative overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.8)), url('${gameState.customBackgrounds.main}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <h2 className="text-2xl font-bold text-amber-400 mb-2">Command Center</h2>
        <p className="text-gray-400 text-sm">Sandy Shores Outpost</p>
        
        {/* Power Management Button */}
        <button
          onClick={() => setShowPowerManagement(true)}
          className="absolute top-4 right-4 bg-yellow-600 hover:bg-yellow-500 p-2 rounded-lg text-white transition-all"
        >
          <Settings size={16} />
        </button>
        
        {/* Energy Bar with Real Power System */}
        <div className="mt-4 w-full max-w-sm mx-auto">
          <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
            <span>Base Power</span>
            <span>{Math.floor((powerEfficiency / 100) * gameState.maxBaseEnergy)}/{gameState.maxBaseEnergy} kW</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-3 overflow-hidden">
            <div 
              className={`h-3 rounded-full transition-all duration-500 ${
                powerEfficiency >= 80 ? 'bg-gradient-to-r from-green-500 to-emerald-500 animate-pulse' :
                powerEfficiency >= 50 ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
                'bg-gradient-to-r from-red-500 to-red-600'
              }`}
              style={{ width: `${powerEfficiency}%` }} 
            />
          </div>
          <div className="flex items-center justify-between text-xs text-gray-400 mt-1">
            <span>Efficiency: {powerEfficiency.toFixed(1)}%</span>
            <span>Cores: {activeCores.length}/{gameState.fusionCores.length}</span>
          </div>
        </div>

        {/* Resource Stats */}
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-xs text-gray-400">Caps</p>
            <p className="text-amber-400 font-bold">{gameState.caps}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-400">Storage</p>
            <p className="text-blue-400 font-bold">{gameState.storageUsed}/{gameState.maxStorage}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-400">Squad</p>
            <p className="text-green-400 font-bold">{gameState.squad.length}/{gameState.maxSquadSize}</p>
          </div>
        </div>
      </div>

      {/* Base Modules */}
      <div className="space-y-3">
        {gameState.baseModules.map((module) => {
          const Icon = getModuleIcon(module.type);
          const isSelected = selectedModule === module.id;
          const hasEnoughPower = powerEfficiency >= 50 || !module.isActive;
          const moduleDescription = getModuleDescription(module);
          
          return (
            <div
              key={module.id}
              onClick={() => setSelectedModule(isSelected ? null : module.id)}
              className={`bg-black/40 backdrop-blur-sm rounded-xl p-4 border-2 cursor-pointer transition-all duration-300 hover:scale-105 ${
                isSelected ? 'border-amber-500 bg-amber-500/10' : 'border-amber-500/20 hover:border-amber-500/40'
              } ${!hasEnoughPower && module.isActive ? 'opacity-75 border-red-500/30' : ''}`}
            >
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${getModuleColor(module.type)} flex items-center justify-center ${
                  hasEnoughPower ? 'animate-pulse' : 'opacity-50'
                }`}>
                  <Icon className="text-white" size={24} />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-white font-semibold">{module.name}</h3>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs bg-amber-500/20 text-amber-400 px-2 py-1 rounded-full">
                        Lv.{module.level}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleModule(module.id);
                        }}
                        className={`text-xs px-2 py-1 rounded-full transition-all ${
                          module.isActive
                            ? hasEnoughPower 
                              ? 'bg-green-500/20 text-green-400'
                              : 'bg-orange-500/20 text-orange-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {module.isActive 
                          ? hasEnoughPower ? 'Online' : 'Low Power'
                          : 'Offline'
                        }
                      </button>
                    </div>
                  </div>
                  
                  <p className="text-gray-400 text-sm mb-2">{moduleDescription}</p>
                  
                  {!hasEnoughPower && module.isActive && (
                    <p className="text-orange-400 text-xs mb-2">⚠️ Insufficient power - reduced efficiency</p>
                  )}
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <span className="text-xs text-yellow-400">
                        Energy: {module.energyCost}kW
                      </span>
                      {module.recruitmentActive && (
                        <span className="text-xs text-blue-400 animate-pulse">
                          🔊 Broadcasting...
                        </span>
                      )}
                    </div>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        upgradeModule(module.id);
                      }}
                      disabled={
                        gameState.caps < module.upgradeCost.caps || 
                        gameState.techFrags < module.upgradeCost.techFrags ||
                        (module.upgradeCost.food && gameState.food < module.upgradeCost.food) ||
                        (module.upgradeCost.water && gameState.water < module.upgradeCost.water)
                      }
                      className="flex items-center space-x-1 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 disabled:cursor-not-allowed px-3 py-1 rounded-lg text-white text-xs font-medium transition-all"
                    >
                      <ArrowUp size={12} />
                      <span>Upgrade</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Expanded Module Details */}
              {isSelected && (
                <div className="mt-4 pt-4 border-t border-gray-600 space-y-3 animate-fade-in">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-black/20 rounded-lg p-3">
                      <h4 className="text-white font-medium mb-2">Upgrade Cost</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Caps:</span>
                          <span className="text-yellow-400">{module.upgradeCost.caps}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Tech Frags:</span>
                          <span className="text-blue-400">{module.upgradeCost.techFrags}</span>
                        </div>
                        {module.upgradeCost.food && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Food:</span>
                            <span className="text-green-400">{module.upgradeCost.food}</span>
                          </div>
                        )}
                        {module.upgradeCost.water && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Water:</span>
                            <span className="text-cyan-400">{module.upgradeCost.water}</span>
                          </div>
                        )}
                      </div>
                      
                      {/* Upgrade Benefits */}
                      <div className="mt-2 p-2 bg-blue-900/20 rounded border border-blue-500/30">
                        <p className="text-blue-400 text-xs font-medium">Next Level Benefits:</p>
                        <p className="text-blue-300 text-xs">
                          {module.type === 'power' && '+ 25kW capacity, improved efficiency'}
                          {module.type === 'storage' && '+ 50 storage slots'}
                          {module.type === 'medical' && '+ 25% faster healing'}
                          {module.type === 'squad' && '+ 2 squad capacity'}
                          {module.type === 'workshop' && '+ crafting recipes, better quality'}
                          {module.type === 'comms' && '+ access to higher tier missions'}
                          {module.type === 'recruitment' && '+ better recruit quality'}
                          {!['power', 'storage', 'medical', 'squad', 'workshop', 'comms', 'recruitment'].includes(module.type) && 'Improved functionality and efficiency'}
                        </p>
                      </div>
                    </div>

                    <div className="bg-black/20 rounded-lg p-3">
                      <h4 className="text-white font-medium mb-2">Module Status</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Power Draw:</span>
                          <span className={module.isActive ? 'text-red-400' : 'text-gray-500'}>
                            {module.isActive ? module.energyCost : 0}kW
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Efficiency:</span>
                          <span className={hasEnoughPower ? 'text-green-400' : 'text-orange-400'}>
                            {hasEnoughPower ? '100%' : `${Math.floor(powerEfficiency)}%`}
                          </span>
                        </div>
                        {module.capacity && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Capacity:</span>
                            <span className="text-blue-400">{module.capacity}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Special Module Actions */}
                  {module.id === 'recruitment-radio' && module.isActive && hasEnoughPower && (
                    <div className="bg-green-900/20 rounded-lg p-3">
                      <h4 className="text-green-400 font-medium mb-2">Recruitment Center</h4>
                      <div className="flex items-center justify-between">
                        <div className="text-sm">
                          <p className="text-gray-300">Cost: {150 + (gameState.squad.length * 50)} caps</p>
                          <p className="text-gray-400">Duration: 5 minutes</p>
                          {!isRecruitmentAvailable() && (
                            <p className="text-red-400">Cooldown: {getRecruitmentCooldown()}m</p>
                          )}
                        </div>
                        <button
                          onClick={handleRecruitment}
                          disabled={!isRecruitmentAvailable() || gameState.caps < (150 + (gameState.squad.length * 50))}
                          className="bg-green-600 hover:bg-green-500 disabled:bg-gray-600 disabled:cursor-not-allowed px-4 py-2 rounded-lg text-white font-medium transition-all"
                        >
                          {module.recruitmentActive ? 'Recruiting...' : 'Start Recruitment'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Power Management Modal */}
      {showPowerManagement && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-black/90 border border-yellow-500/30 rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-gray-600">
              <h3 className="text-yellow-400 font-bold text-lg">Power Management</h3>
              <button
                onClick={() => setShowPowerManagement(false)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <PowerManagement />
          </div>
        </div>
      )}
    </div>
  );
};
