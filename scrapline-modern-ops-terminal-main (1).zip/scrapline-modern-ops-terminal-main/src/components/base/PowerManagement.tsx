
import React, { useState } from 'react';
import { useGame } from '@/context/GameContext';
import { Battery, Plus, Minus, Power, Zap, AlertTriangle, TrendingUp, Settings } from 'lucide-react';

export const PowerManagement = () => {
  const { gameState, manageFusionCores, spendCurrency, addItem, addNotification } = useGame();
  const [showAddCore, setShowAddCore] = useState(false);

  const totalPowerGeneration = gameState.fusionCores
    .filter(core => core.isActive && core.currentCharge > 0)
    .reduce((sum, core) => sum + (core.efficiency / 5), 0);

  const totalPowerConsumption = gameState.baseModules
    .filter(module => module.isActive)
    .reduce((sum, module) => sum + (module.energyCost || 0), 0);

  const netPower = totalPowerGeneration - totalPowerConsumption;
  const powerEfficiency = totalPowerConsumption > 0 
    ? Math.min(100, (totalPowerGeneration / totalPowerConsumption) * 100)
    : 100;

  const addFusionCore = () => {
    const cost = 200 + (gameState.fusionCores.length * 50);
    if (gameState.caps < cost) {
      addNotification({
        id: `power-error-${Date.now()}`,
        type: 'error',
        title: 'Insufficient Funds',
        message: `Need ${cost} caps to purchase fusion core`,
        priority: 'medium'
      });
      return;
    }
    
    if (spendCurrency('caps', cost)) {
      manageFusionCores('add');
      addNotification({
        id: `power-success-${Date.now()}`,
        type: 'success',
        title: 'Fusion Core Added',
        message: 'New fusion core installed successfully',
        priority: 'low'
      });
      setShowAddCore(false);
    }
  };

  const buyCoreFromInventory = () => {
    const fusionCoreItem = gameState.inventory.find(item => item.id === 'fusion-core');
    if (!fusionCoreItem || fusionCoreItem.quantity <= 0) {
      addNotification({
        id: `power-error-${Date.now()}`,
        type: 'error',
        title: 'No Cores Available',
        message: 'No fusion cores in inventory',
        priority: 'medium'
      });
      return;
    }
    
    manageFusionCores('add');
    addNotification({
      id: `power-success-${Date.now()}`,
      type: 'success',
      title: 'Fusion Core Installed',
      message: 'Fusion core from inventory installed',
      priority: 'low'
    });
  };

  return (
    <div className="space-y-6">
      {/* Modern Power Overview */}
      <div className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-2xl p-6 border border-yellow-500/20 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-yellow-400 flex items-center">
            <Power className="mr-3" size={28} />
            Power Grid
          </h3>
          <div className="flex items-center space-x-2 text-sm">
            <div className={`w-3 h-3 rounded-full ${netPower > 0 ? 'bg-green-400' : 'bg-red-400'} animate-pulse`}></div>
            <span className="text-gray-300">{netPower > 0 ? 'Online' : 'Critical'}</span>
          </div>
        </div>

        {/* Power Metrics Grid */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <div className="bg-black/30 rounded-xl p-4 border border-green-500/20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Generation</span>
              <TrendingUp className="text-green-400" size={16} />
            </div>
            <div className="text-3xl font-bold text-green-400">{totalPowerGeneration.toFixed(1)}</div>
            <div className="text-xs text-gray-500">Units/min</div>
          </div>
          
          <div className="bg-black/30 rounded-xl p-4 border border-red-500/20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Consumption</span>
              <Settings className="text-red-400" size={16} />
            </div>
            <div className="text-3xl font-bold text-red-400">{totalPowerConsumption}</div>
            <div className="text-xs text-gray-500">Units/min</div>
          </div>
        </div>

        {/* Enhanced Efficiency Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm mb-3">
            <span className="text-gray-300 font-medium">System Efficiency</span>
            <span className={`font-bold text-lg ${
              powerEfficiency >= 80 ? 'text-green-400' : 
              powerEfficiency >= 50 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {powerEfficiency.toFixed(1)}%
            </span>
          </div>
          <div className="relative w-full bg-gray-800 rounded-full h-4 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-700 to-gray-600"></div>
            <div 
              className={`relative h-full rounded-full transition-all duration-1000 ${
                powerEfficiency >= 80 ? 'bg-gradient-to-r from-green-500 to-green-400' : 
                powerEfficiency >= 50 ? 'bg-gradient-to-r from-yellow-500 to-yellow-400' : 
                'bg-gradient-to-r from-red-500 to-red-400'
              } shadow-lg`}
              style={{ width: `${Math.min(100, powerEfficiency)}%` }}
            >
              <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
            </div>
          </div>
        </div>

        {/* Critical Warning */}
        {powerEfficiency < 50 && (
          <div className="bg-gradient-to-r from-red-900/50 to-orange-900/50 border border-red-500/40 rounded-xl p-4 mb-4">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="text-red-400 animate-bounce" size={20} />
              <div>
                <p className="text-red-300 font-semibold">POWER GRID CRITICAL</p>
                <p className="text-red-400 text-sm mt-1">
                  Multiple systems failing. Add fusion cores immediately.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Net Power Display */}
        <div className="text-center">
          <div className="text-sm text-gray-400 mb-1">Net Power Output</div>
          <div className={`text-2xl font-bold ${netPower > 0 ? 'text-green-400' : 'text-red-400'}`}>
            {netPower > 0 ? '+' : ''}{netPower.toFixed(1)} Units
          </div>
        </div>
      </div>

      {/* Modern Fusion Core Management */}
      <div className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-2xl p-6 border border-blue-500/20 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-xl font-bold text-blue-400 flex items-center">
            <Battery className="mr-3" size={24} />
            Fusion Cores ({gameState.fusionCores.length})
          </h4>
          <button
            onClick={() => setShowAddCore(true)}
            className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 p-3 rounded-xl text-white transition-all shadow-lg hover:shadow-blue-500/25"
          >
            <Plus size={18} />
          </button>
        </div>

        {/* Core Grid */}
        <div className="grid gap-4">
          {gameState.fusionCores.map((core, index) => (
            <div
              key={core.id}
              className={`p-4 rounded-xl border-2 transition-all ${
                core.isActive 
                  ? 'border-green-500/50 bg-gradient-to-r from-green-900/20 to-blue-900/20' 
                  : 'border-gray-500/30 bg-black/30'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${core.isActive ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`}></div>
                  <span className="text-white font-semibold">Fusion Core #{index + 1}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      manageFusionCores(core.isActive ? 'deactivate' : 'activate', core.id);
                      addNotification({
                        id: `core-toggle-${Date.now()}`,
                        type: 'success',
                        title: 'Core Status Changed',
                        message: `Core ${index + 1} ${core.isActive ? 'deactivated' : 'activated'}`,
                        priority: 'low'
                      });
                    }}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      core.isActive 
                        ? 'bg-red-600 hover:bg-red-500 text-white' 
                        : 'bg-green-600 hover:bg-green-500 text-white'
                    }`}
                  >
                    {core.isActive ? 'Deactivate' : 'Activate'}
                  </button>
                  <button
                    onClick={() => {
                      manageFusionCores('remove', core.id);
                      addNotification({
                        id: `core-remove-${Date.now()}`,
                        type: 'success',
                        title: 'Core Removed',
                        message: `Fusion core ${index + 1} safely removed`,
                        priority: 'low'
                      });
                    }}
                    className="bg-gray-600 hover:bg-gray-500 p-2 rounded-lg text-white transition-all"
                  >
                    <Minus size={16} />
                  </button>
                </div>
              </div>

              {/* Enhanced Core Stats */}
              <div className="grid grid-cols-3 gap-4 mb-3">
                <div className="text-center">
                  <p className="text-xs text-gray-400">Charge</p>
                  <p className="text-blue-400 font-bold">
                    {Math.floor(core.currentCharge)}/{core.maxCharge}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-gray-400">Efficiency</p>
                  <p className="text-green-400 font-bold">{core.efficiency}%</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-gray-400">Output</p>
                  <p className="text-yellow-400 font-bold">{(core.efficiency / 5).toFixed(1)}</p>
                </div>
              </div>

              {/* Enhanced Charge Bar */}
              <div className="relative w-full bg-gray-800 rounded-full h-3 overflow-hidden mb-2">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ${
                    core.currentCharge > core.maxCharge * 0.5 ? 'bg-gradient-to-r from-blue-500 to-cyan-400' :
                    core.currentCharge > core.maxCharge * 0.2 ? 'bg-gradient-to-r from-yellow-500 to-orange-400' : 
                    'bg-gradient-to-r from-red-500 to-red-400'
                  } shadow-lg`}
                  style={{ width: `${(core.currentCharge / core.maxCharge) * 100}%` }}
                >
                  <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                </div>
              </div>

              {/* Runtime Estimate */}
              {core.isActive && core.currentCharge > 0 && (
                <div className="text-xs text-gray-400 flex items-center">
                  <Zap size={12} className="mr-1" />
                  Runtime: {Math.floor(core.currentCharge / Math.max(1, totalPowerConsumption / 60))} minutes
                </div>
              )}
            </div>
          ))}
        </div>

        {gameState.fusionCores.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            <Battery size={64} className="mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium">No Fusion Cores Online</p>
            <p className="text-sm">Install cores to power your base systems</p>
          </div>
        )}
      </div>

      {/* Enhanced Add Core Modal */}
      {showAddCore && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 border border-blue-500/30 rounded-2xl p-8 max-w-md w-full shadow-2xl">
            <h3 className="text-blue-400 font-bold text-2xl mb-6 text-center">Add Fusion Core</h3>
            
            <div className="space-y-6">
              <div className="bg-black/40 p-6 rounded-xl border border-gray-500/30">
                <h4 className="text-white font-semibold mb-3 flex items-center">
                  <Plus className="mr-2" size={18} />
                  Purchase New Core
                </h4>
                <p className="text-gray-400 text-sm mb-4">
                  Cost: <span className="text-yellow-400 font-bold">{200 + (gameState.fusionCores.length * 50)} caps</span>
                </p>
                <button
                  onClick={addFusionCore}
                  disabled={gameState.caps < (200 + (gameState.fusionCores.length * 50))}
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed p-4 rounded-xl text-white font-semibold transition-all shadow-lg"
                >
                  Purchase Core
                </button>
              </div>

              {gameState.inventory.find(item => item.id === 'fusion-core')?.quantity > 0 && (
                <div className="bg-black/40 p-6 rounded-xl border border-green-500/30">
                  <h4 className="text-white font-semibold mb-3 flex items-center">
                    <Battery className="mr-2" size={18} />
                    Use Inventory Core
                  </h4>
                  <p className="text-gray-400 text-sm mb-4">
                    Available: <span className="text-green-400 font-bold">{gameState.inventory.find(item => item.id === 'fusion-core')?.quantity} cores</span>
                  </p>
                  <button
                    onClick={buyCoreFromInventory}
                    className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 p-4 rounded-xl text-white font-semibold transition-all shadow-lg"
                  >
                    Install Core
                  </button>
                </div>
              )}
            </div>
            
            <button
              onClick={() => setShowAddCore(false)}
              className="w-full mt-6 bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-500 hover:to-gray-400 p-4 rounded-xl text-white font-semibold transition-all"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
