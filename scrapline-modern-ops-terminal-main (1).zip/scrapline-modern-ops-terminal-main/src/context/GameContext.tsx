import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { GAME_ITEMS, GameItem } from '@/data/GameItems';

// Define types
export type ResourceType = 'caps' | 'scrip' | 'nuclearFuel' | 'food' | 'water' | 'techFrags';

export type MissionType = 'exploration' | 'combat' | 'trading' | 'rescue' | 'stealth';

export type SquadMemberStatus = 'available' | 'mission' | 'injured' | 'dead';

export type ModuleType = 'power' | 'storage' | 'recruitment' | 'defense' | 'production' | 'medical' | 'squad' | 'workshop' | 'comms' | 'intel';

export type ButtonPosition = 'top' | 'bottom' | 'original';

export type NotificationType = 'combat' | 'mission' | 'trade' | 'default' | 'resource' | 'upgrade' | 'error' | 'success' | 'event';

export interface InventoryItem extends GameItem {
  quantity: number;
}

export interface TradeItem extends GameItem {
  price: number;
  currency: 'caps' | 'scrip';
  stock: number;
  category: string;
}

export interface SquadMember {
  id: string;
  name: string;
  level: number;
  experience: number;
  specialization: string;
  status: SquadMemberStatus;
  stats: {
    health: number;
    maxHealth: number;
    combat: number;
    stealth: number;
    tech: number;
    charisma: number;
    hunger: number;
    thirst: number;
  };
  equipment: {
    weapon?: string;
    armor?: string;
    accessory?: string;
  };
  inventory: InventoryItem[];
  traits?: string[];
}

export interface Mission {
  id: string;
  title: string;
  type: MissionType;
  difficulty: number;
  requirements: {
    level: number;
    squadSize: number;
  };
  rewards: {
    caps: number;
    experience: number;
    scrip?: number;
  };
  duration: number;
  description: string;
  location: string;
  assignedSquad: string[];
  startTime: number;
}

export interface BaseModule {
  id: string;
  name: string;
  description: string;
  type: ModuleType;
  level: number;
  maxLevel: number;
  isActive: boolean;
  powerConsumption?: number;
  energyCost: number;
  storageCapacity?: number;
  capacity?: number;
  recruitmentActive?: boolean;
  upgradeCost: {
    caps: number;
    techFrags: number;
    food?: number;
    water?: number;
  };
}

export interface TerminalEntry {
  id: string;
  title: string;
  content: string;
  timestamp: number;
  category: string;
  unlockedBy?: string;
}

export interface GameNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp?: number;
  isRead?: boolean;
  priority: 'low' | 'medium' | 'high';
  character?: {
    name: string;
    image: string;
    faction: string;
  };
  dialogueOptions?: Array<{
    text: string;
    outcome: {
      caps?: number;
      items?: string[];
      reputation?: string;
    };
    requirement?: {
      charisma?: number;
    };
  }>;
}

export interface FusionCore {
  id: string;
  currentCharge: number;
  maxCharge: number;
  efficiency: number;
  isActive: boolean;
  stationId?: string;
}

export interface EncounterEvent {
  id: string;
  type: string;
  timestamp: number;
  description: string;
  title?: string;
  message?: string;
  character?: {
    name: string;
    faction: string;
  };
  choices: Array<{
    text: string;
    outcome: any;
  }>;
  dialogueOptions?: Array<{
    text: string;
    outcome: any;
    requirement?: {
      charisma?: number;
    };
  }>;
  responded?: boolean;
  outcome?: string;
}

export interface GameState {
  isLoggedIn: boolean;
  username: string;
  commanderLevel: number;
  commanderExperience: number;
  caps: number;
  scrip: number;
  nuclearFuel: number;
  food: number;
  water: number;
  techFrags: number;
  inventory: InventoryItem[];
  squad: SquadMember[];
  maxSquadSize: number;
  activeMissions: Mission[];
  completedMissions: string[];
  baseModules: BaseModule[];
  maxBaseEnergy: number;
  baseEnergy: number;
  storageUsed: number;
  maxStorage: number;
  tradingInventory: TradeItem[];
  lastTradeRefresh: number;
  uiSettings: {
    theme: string;
    buttonPosition: ButtonPosition;
    showNotifications: boolean;
  };
  terminalEntries: TerminalEntry[];
  pendingNotifications: GameNotification[];
  combatCooldowns: { [key: string]: number };
  recruitmentCooldown: number;
  customBackgrounds: {
    main: string;
    combat: string;
    trading: string;
  };
  fusionCores: FusionCore[];
  encounterHistory: EncounterEvent[];
  vendorCaps: number;
  activeEvents: EncounterEvent[];
  terminalLore: TerminalEntry[];
}

interface GameContextType {
  gameState: GameState;
  login: (username: string, password?: string) => boolean;
  logout: () => void;
  addCurrency: (type: ResourceType, amount: number) => void;
  spendCurrency: (type: ResourceType, amount: number) => boolean;
  useConsumable: (itemId: string, squadMemberId?: string) => void;
  removeItem: (itemId: string, quantity: number) => void;
  addItem: (item: InventoryItem) => void;
  buyItem: (item: TradeItem) => void;
  sellItem: (itemId: string, quantity: number) => void;
  startMission: (missionId: string, squadMembers: string[]) => boolean;
  completeMission: (missionId: string) => void;
  addExperience: (squadMemberId: string, amount: number) => void;
  upgradeModule: (moduleId: string) => void;
  toggleModule: (moduleId: string) => void;
  equipItem: (squadMemberId: string, itemId: string, slot: keyof SquadMember['equipment']) => void;
  updateSettings: (settings: Partial<GameState['uiSettings']>) => void;
  updateUISettings: (settings: Partial<GameState['uiSettings']>) => void;
  transferItemToSquad: (itemId: string, squadMemberId: string, quantity: number) => void;
  useChem: (chemId: string, squadMemberId: string) => void;
  startRecruitment: () => boolean;
  addNotification: (notification: Omit<GameNotification, 'timestamp' | 'isRead'>) => void;
  markNotificationAsRead: (notificationId: string) => void;
  clearNotifications: () => void;
  addTerminalEntry: (entry: Omit<TerminalEntry, 'timestamp'>) => void;
  abortMission: (missionId: string) => void;
  respondToEncounter: (encounterId: string, choiceIndex: number) => void;
  manageFusionCores: (action: 'add' | 'remove' | 'activate' | 'deactivate', coreId?: string) => void;
  addFusionCore: (stationId: string) => void;
  removeFusionCore: (stationId: string, coreId: string) => void;
  refreshTrading: () => void;
  getModuleDetails: (moduleId: string) => BaseModule | undefined;
  dismissNotification: (notificationId: string) => void;
  handleDialogueChoice: (notificationId: string, choiceIndex: number) => void;
  handleEventChoice: (eventId: string, choiceIndex: number) => void;
}

// Create context
const GameContext = createContext<GameContextType | undefined>(undefined);

// Provider component
const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [gameState, setGameState] = useState<GameState>({
    isLoggedIn: false,
    username: '',
    commanderLevel: 1,
    commanderExperience: 0,
    caps: 100,
    scrip: 0,
    nuclearFuel: 10,
    food: 20,
    water: 15,
    techFrags: 5,
    inventory: [
      // Add initial fusion core
      {
        id: 'fusion-core',
        name: 'Fusion Core',
        type: 'power',
        rarity: 'common',
        description: 'A portable fusion core that provides stable power.',
        value: 200,
        weight: 5,
        quantity: 1,
        icon: '⚡',
        function: 'Provides power to base systems'
      },
      // Add 2 basic guns
      {
        id: 'pipe-pistol',
        name: 'Pipe Pistol',
        type: 'weapon',
        rarity: 'common',
        description: 'A makeshift pistol cobbled together from scrap.',
        value: 50,
        weight: 2,
        quantity: 2,
        icon: '🔫',
        function: 'Basic ranged weapon',
        stats: { damage: 15, accuracy: 60 }
      }
    ],
    squad: [],
    maxSquadSize: 5,
    activeMissions: [],
    completedMissions: [],
    baseModules: [
      {
        id: 'fusion-core',
        name: 'Fusion Core',
        description: 'Provides basic power to the base.',
        type: 'power',
        level: 1,
        maxLevel: 3,
        isActive: true,
        powerConsumption: -20,
        energyCost: 0,
        upgradeCost: { caps: 200, techFrags: 10 }
      },
      {
        id: 'storage-room',
        name: 'Storage Room',
        description: 'Increases storage capacity for resources.',
        type: 'storage',
        level: 1,
        maxLevel: 3,
        isActive: true,
        powerConsumption: 5,
        energyCost: 5,
        storageCapacity: 100,
        capacity: 100,
        upgradeCost: { caps: 150, techFrags: 5 }
      },
      {
        id: 'recruitment-radio',
        name: 'Recruitment Radio',
        description: 'Attracts new squad members to the base.',
        type: 'recruitment',
        level: 1,
        maxLevel: 1,
        isActive: false,
        powerConsumption: 10,
        energyCost: 10,
        upgradeCost: { caps: 300, techFrags: 15 }
      },
      {
        id: 'defense',
        name: 'Defense Systems',
        description: 'Provides basic defense against raider attacks.',
        type: 'defense',
        level: 1,
        maxLevel: 3,
        isActive: true,
        powerConsumption: 15,
        energyCost: 15,
        upgradeCost: { caps: 250, techFrags: 12 }
      },
      {
        id: 'workshop',
        name: 'Workshop',
        description: 'Crafting and weapon modification station.',
        type: 'workshop',
        level: 1,
        maxLevel: 3,
        isActive: true,
        powerConsumption: 10,
        energyCost: 10,
        upgradeCost: { caps: 180, techFrags: 8 }
      },
      {
        id: 'squad-room',
        name: 'Squad Room',
        description: 'Housing for squad members.',
        type: 'squad',
        level: 1,
        maxLevel: 3,
        isActive: true,
        powerConsumption: 8,
        energyCost: 8,
        upgradeCost: { caps: 200, techFrags: 10 }
      },
      {
        id: 'medical-bay',
        name: 'Medical Bay',
        description: 'Heals injured squad members.',
        type: 'medical',
        level: 1,
        maxLevel: 3,
        isActive: true,
        powerConsumption: 12,
        energyCost: 12,
        upgradeCost: { caps: 220, techFrags: 12 }
      },
      {
        id: 'comms',
        name: 'Communications',
        description: 'Access to faction missions and intel.',
        type: 'comms',
        level: 1,
        maxLevel: 3,
        isActive: true,
        powerConsumption: 15,
        energyCost: 15,
        upgradeCost: { caps: 300, techFrags: 15 }
      },
      {
        id: 'intel',
        name: 'Intelligence Center',
        description: 'Advanced mission intelligence and threat analysis.',
        type: 'intel',
        level: 1,
        maxLevel: 3,
        isActive: false,
        powerConsumption: 18,
        energyCost: 18,
        upgradeCost: { caps: 350, techFrags: 20 }
      },
      {
        id: 'barracks',
        name: 'Barracks',
        description: 'Additional housing and morale boost.',
        type: 'squad',
        level: 1,
        maxLevel: 3,
        isActive: false,
        powerConsumption: 10,
        energyCost: 10,
        upgradeCost: { caps: 250, techFrags: 15 }
      }
    ],
    maxBaseEnergy: 100,
    baseEnergy: 100,
    storageUsed: 0,
    maxStorage: 100,
    tradingInventory: [],
    lastTradeRefresh: 0,
    uiSettings: {
      theme: 'dark',
      buttonPosition: 'bottom',
      showNotifications: true
    },
    terminalEntries: [
      {
        id: 'terminal-1',
        title: 'Welcome to Fallout: Scrapline',
        content: 'Manage your base, scavenge resources, and lead your squad to survival.',
        timestamp: Date.now(),
        category: 'system'
      }
    ],
    pendingNotifications: [],
    combatCooldowns: {},
    recruitmentCooldown: 0,
    customBackgrounds: {
      main: '/lovable-uploads/9a1696e2-cf2a-4e20-90dd-45942d3c601d.png',
      combat: 'url(./img/bg/combat-bg.jpg)',
      trading: 'url(./img/bg/trading-bg.jpg)'
    },
    fusionCores: [
      // Add initial fusion core
      {
        id: uuidv4(),
        currentCharge: 100,
        maxCharge: 100,
        efficiency: 100,
        isActive: true,
        stationId: 'fusion-core'
      }
    ],
    encounterHistory: [],
    vendorCaps: 1000,
    activeEvents: [],
    terminalLore: []
  });

  useEffect(() => {
    // Load initial game data or perform setup
    generateInitialSquad();
    refreshTrading();
  }, []);

  // Authentication functions
  const login = (username: string, password?: string): boolean => {
    setGameState(prev => ({ 
      ...prev, 
      isLoggedIn: true, 
      username,
      squad: generateInitialSquad()
    }));
    return true;
  };

  const logout = () => {
    setGameState(prev => ({ ...prev, isLoggedIn: false, username: '' }));
  };

  // Resource management functions
  const addCurrency = (type: ResourceType, amount: number) => {
    setGameState(prev => ({ ...prev, [type]: prev[type] + amount }));
  };

  const spendCurrency = (type: ResourceType, amount: number): boolean => {
    if (gameState[type] >= amount) {
      setGameState(prev => ({ ...prev, [type]: prev[type] - amount }));
      return true;
    }
    return false;
  };

  // Inventory management functions
  const useConsumable = (itemId: string, squadMemberId?: string) => {
    setGameState(prev => {
      const itemIndex = prev.inventory.findIndex(item => item.id === itemId);
      if (itemIndex === -1 || prev.inventory[itemIndex].quantity <= 0) return prev;

      const item = prev.inventory[itemIndex];
      let newState = { ...prev };

      // Apply effects
      if (item.effects) {
        Object.entries(item.effects).forEach(([effect, value]) => {
          if (effect === 'health' && squadMemberId) {
            const squadMemberIndex = newState.squad.findIndex(member => member.id === squadMemberId);
            if (squadMemberIndex !== -1) {
              newState.squad[squadMemberIndex].stats.health = Math.min(
                newState.squad[squadMemberIndex].stats.maxHealth,
                newState.squad[squadMemberIndex].stats.health + value
              );
            }
          } else if (effect === 'thirst' && squadMemberId) {
            const squadMemberIndex = newState.squad.findIndex(member => member.id === squadMemberId);
            if (squadMemberIndex !== -1) {
              newState.squad[squadMemberIndex].stats.thirst = Math.max(
                0,
                newState.squad[squadMemberIndex].stats.thirst + value
              );
            }
          } else if (effect === 'hunger' && squadMemberId) {
            const squadMemberIndex = newState.squad.findIndex(member => member.id === squadMemberId);
            if (squadMemberIndex !== -1) {
              newState.squad[squadMemberIndex].stats.hunger = Math.max(
                0,
                newState.squad[squadMemberIndex].stats.hunger + value
              );
            }
          }
        });
      }

      // Remove the item from inventory
      newState.inventory[itemIndex].quantity -= 1;
      if (newState.inventory[itemIndex].quantity === 0) {
        newState.inventory.splice(itemIndex, 1);
      }

      return newState;
    });
  };

  const removeItem = (itemId: string, quantity: number) => {
    setGameState(prev => {
      const itemIndex = prev.inventory.findIndex(item => item.id === itemId);
      if (itemIndex === -1 || prev.inventory[itemIndex].quantity < quantity) return prev;

      const newInventory = [...prev.inventory];
      newInventory[itemIndex] = { ...newInventory[itemIndex], quantity: newInventory[itemIndex].quantity - quantity };

      if (newInventory[itemIndex].quantity <= 0) {
        newInventory.splice(itemIndex, 1);
      }

      return { ...prev, inventory: newInventory };
    });
  };

  const addItem = (item: InventoryItem) => {
    setGameState(prev => {
      const existingItemIndex = prev.inventory.findIndex(invItem => invItem.id === item.id);

      if (existingItemIndex !== -1) {
        const newInventory = [...prev.inventory];
        newInventory[existingItemIndex].quantity += item.quantity;
        return { ...prev, inventory: newInventory };
      } else {
        return { ...prev, inventory: [...prev.inventory, item] };
      }
    });
  };

  // Trading functions
  const buyItem = (item: TradeItem) => {
    setGameState(prev => {
      if (prev.caps < item.price || item.stock <= 0) return prev;

      const newCaps = prev.caps - item.price;
      const newStock = item.stock - 1;

      // Update trading inventory
      const newTradingInventory = prev.tradingInventory.map(tradeItem =>
        tradeItem.id === item.id ? { ...tradeItem, stock: newStock } : tradeItem
      );

      // Add item to player inventory
      const existingItemIndex = prev.inventory.findIndex(invItem => invItem.id === item.id);
      let newInventory = [...prev.inventory];

      if (existingItemIndex !== -1) {
        newInventory[existingItemIndex].quantity += 1;
      } else {
        newInventory.push({
          id: item.id,
          name: item.name,
          type: item.type,
          rarity: item.rarity,
          description: item.description,
          value: item.value,
          weight: item.weight,
          quantity: 1,
          icon: item.icon || '📦',
          function: item.function,
          stats: item.stats,
          effects: item.effects
        });
      }

      return { ...prev, caps: newCaps, tradingInventory: newTradingInventory, inventory: newInventory };
    });
  };

  const sellItem = (itemId: string, quantity: number) => {
    setGameState(prev => {
      const itemIndex = prev.inventory.findIndex(item => item.id === itemId);
      if (itemIndex === -1 || prev.inventory[itemIndex].quantity < quantity) return prev;

      const item = prev.inventory[itemIndex];
      const newCaps = prev.caps + (item.value * quantity);

      const newInventory = [...prev.inventory];
      newInventory[itemIndex] = { ...newInventory[itemIndex], quantity: newInventory[itemIndex].quantity - quantity };

      if (newInventory[itemIndex].quantity <= 0) {
        newInventory.splice(itemIndex, 1);
      }

      return { ...prev, caps: newCaps, inventory: newInventory };
    });
  };

  // Mission functions
  const startMission = (missionId: string, squadMembers: string[]): boolean => {
    // First check if it's a combat mission from COMBAT_TARGETS
    const isValidOperation = setGameState(prev => {
      if (prev.activeMissions.find(mission => mission.id === missionId)) {
        addNotification({
          id: `mission-error-${Date.now()}`,
          type: 'error',
          title: 'Mission Already Active',
          message: 'This mission is already in progress',
          priority: 'high'
        });
        return prev;
      }

      // Check if squad members are available
      const isSquadAvailable = squadMembers.every(memberId =>
        prev.squad.find(member => member.id === memberId && member.status === 'available')
      );

      if (!isSquadAvailable) {
        addNotification({
          id: `squad-error-${Date.now()}`,
          type: 'error',
          title: 'Squad Unavailable',
          message: 'One or more selected squad members are not available',
          priority: 'high'
        });
        return prev;
      }

      // Set squad members to "on mission" status
      const newSquad = prev.squad.map(member =>
        squadMembers.includes(member.id) ? { ...member, status: 'mission' as const } : member
      );

      // Create mission based on the actual missionId - this fixes the bug
      let mission: Mission;
      
      if (missionId.startsWith('combat-')) {
        // Extract target info from combat mission ID
        const targetId = missionId.replace('combat-', '').split('-')[0];
        mission = {
          id: missionId,
          title: `Combat Mission: ${targetId}`,
          type: 'combat',
          difficulty: 5,
          requirements: { level: 1, squadSize: 1 },
          rewards: { caps: 150, experience: 75, scrip: 10 },
          duration: 3,
          description: `Engage hostile forces in combat.`,
          location: 'Combat Zone',
          assignedSquad: squadMembers,
          startTime: Date.now()
        };
      } else if (missionId.startsWith('ss-')) {
        // Sandy Shores quest missions
        mission = {
          id: missionId,
          title: `Operation: ${missionId}`,
          type: 'exploration',
          difficulty: 3,
          requirements: { level: 1, squadSize: 1 },
          rewards: { caps: 100, experience: 50 },
          duration: 2,
          description: `Carry out operation ${missionId}.`,
          location: 'Sandy Shores',
          assignedSquad: squadMembers,
          startTime: Date.now()
        };
      } else {
        // Default mission
        mission = {
          id: missionId,
          title: 'Special Operation',
          type: 'exploration',
          difficulty: 3,
          requirements: { level: 1, squadSize: 1 },
          rewards: { caps: 100, experience: 50 },
          duration: 2,
          description: 'A special operation mission.',
          location: 'Unknown',
          assignedSquad: squadMembers,
          startTime: Date.now()
        };
      }

      addNotification({
        id: `mission-start-${Date.now()}`,
        type: 'success',
        title: 'Mission Started',
        message: `${mission.title} has begun`,
        priority: 'medium'
      });

      return {
        ...prev,
        squad: newSquad,
        activeMissions: [...prev.activeMissions, mission]
      };
    });
    return true;
  };

  const completeMission = (missionId: string) => {
    setGameState(prev => {
      const mission = prev.activeMissions.find(m => m.id === missionId);
      if (!mission) return prev;

      // Return squad members to available status
      const newSquad = prev.squad.map(member =>
        mission.assignedSquad.includes(member.id) ? { ...member, status: 'available' as const } : member
      );

      // Award rewards
      let newState = { ...prev, caps: prev.caps + mission.rewards.caps, completedMissions: [...prev.completedMissions, missionId] };

      mission.assignedSquad.forEach(memberId => {
        newState = addExperienceToSquadMember(newState, memberId, mission.rewards.experience);
      });

      return {
        ...newState,
        squad: newSquad,
        activeMissions: prev.activeMissions.filter(m => m.id !== missionId)
      };
    });
  };

  const addExperienceToSquadMember = (state: GameState, squadMemberId: string, amount: number): GameState => {
    const squadMemberIndex = state.squad.findIndex(member => member.id === squadMemberId);
    if (squadMemberIndex === -1) return state;

    const newSquad = [...state.squad];
    newSquad[squadMemberIndex].experience += amount;

    // Level up logic (example: 100 XP per level)
    const xpToNextLevel = newSquad[squadMemberIndex].level * 100;
    if (newSquad[squadMemberIndex].experience >= xpToNextLevel) {
      newSquad[squadMemberIndex].level += 1;
      newSquad[squadMemberIndex].experience -= xpToNextLevel;
    }

    return { ...state, squad: newSquad };
  };

  const addExperience = (squadMemberId: string, amount: number) => {
    setGameState(prev => {
      return addExperienceToSquadMember(prev, squadMemberId, amount);
    });
  };

  // Base management functions
  const upgradeModule = (moduleId: string) => {
    setGameState(prev => {
      const moduleIndex = prev.baseModules.findIndex(module => module.id === moduleId);
      if (moduleIndex === -1 || prev.baseModules[moduleIndex].level >= prev.baseModules[moduleIndex].maxLevel) return prev;

      const module = prev.baseModules[moduleIndex];
      
      // Check if player has enough resources
      if (prev.caps < module.upgradeCost.caps || prev.techFrags < module.upgradeCost.techFrags) return prev;
      if (module.upgradeCost.food && prev.food < module.upgradeCost.food) return prev;
      if (module.upgradeCost.water && prev.water < module.upgradeCost.water) return prev;

      const newModules = [...prev.baseModules];
      newModules[moduleIndex] = { ...newModules[moduleIndex], level: newModules[moduleIndex].level + 1 };

      // Deduct resources
      let newState = {
        ...prev,
        baseModules: newModules,
        caps: prev.caps - module.upgradeCost.caps,
        techFrags: prev.techFrags - module.upgradeCost.techFrags
      };

      if (module.upgradeCost.food) {
        newState.food -= module.upgradeCost.food;
      }
      if (module.upgradeCost.water) {
        newState.water -= module.upgradeCost.water;
      }

      return newState;
    });
  };

  const toggleModule = (moduleId: string) => {
    setGameState(prev => {
      const moduleIndex = prev.baseModules.findIndex(module => module.id === moduleId);
      if (moduleIndex === -1) return prev;

      const newModules = [...prev.baseModules];
      newModules[moduleIndex] = { ...newModules[moduleIndex], isActive: !newModules[moduleIndex].isActive };

      return { ...prev, baseModules: newModules };
    });
  };

  // Squad management functions
  const equipItem = (squadMemberId: string, itemId: string, slot: keyof SquadMember['equipment']) => {
    setGameState(prev => {
      const squadMemberIndex = prev.squad.findIndex(member => member.id === squadMemberId);
      if (squadMemberIndex === -1) return prev;

      const newSquad = [...prev.squad];
      newSquad[squadMemberIndex].equipment[slot] = itemId;

      return { ...prev, squad: newSquad };
    });
  };

  // Settings functions
  const updateSettings = (settings: Partial<GameState['uiSettings']>) => {
    setGameState(prev => ({ ...prev, uiSettings: { ...prev.uiSettings, ...settings } }));
  };

  const updateUISettings = (settings: Partial<GameState['uiSettings']>) => {
    updateSettings(settings);
  };

  const transferItemToSquad = (itemId: string, squadMemberId: string, quantity: number) => {
    setGameState(prev => {
      const itemIndex = prev.inventory.findIndex(item => item.id === itemId);
      if (itemIndex === -1 || prev.inventory[itemIndex].quantity < quantity) return prev;

      const squadMemberIndex = prev.squad.findIndex(member => member.id === squadMemberId);
      if (squadMemberIndex === -1) return prev;

      const item = prev.inventory[itemIndex];
      const transferItem = { ...item, quantity };

      const newInventory = [...prev.inventory];
      if (newInventory[itemIndex].quantity === quantity) {
        newInventory.splice(itemIndex, 1);
      } else {
        newInventory[itemIndex] = { ...newInventory[itemIndex], quantity: newInventory[itemIndex].quantity - quantity };
      }

      const newSquad = [...prev.squad];
      const existingItemIndex = newSquad[squadMemberIndex].inventory.findIndex(inv => inv.id === itemId);
      
      if (existingItemIndex >= 0) {
        newSquad[squadMemberIndex].inventory[existingItemIndex].quantity += quantity;
      } else {
        newSquad[squadMemberIndex].inventory.push(transferItem);
      }

      return { ...prev, inventory: newInventory, squad: newSquad };
    });
  };

  const useChem = (chemId: string, squadMemberId: string) => {
    setGameState(prev => {
      const chemIndex = prev.inventory.findIndex(item => item.id === chemId && item.type === 'chem');
      if (chemIndex === -1 || prev.inventory[chemIndex].quantity <= 0) return prev;

      const squadMemberIndex = prev.squad.findIndex(member => member.id === squadMemberId);
      if (squadMemberIndex === -1) return prev;

      const chem = prev.inventory[chemIndex];
      let newState = { ...prev };

      // Apply effects
      if (chem.effects) {
        Object.entries(chem.effects).forEach(([effect, value]) => {
          if (effect === 'damage') {
            newState.squad[squadMemberIndex].stats.combat += value;
          } else if (effect === 'stealth') {
            newState.squad[squadMemberIndex].stats.stealth += value;
          } else if (effect === 'accuracy') {
            // Apply accuracy bonus (could be stored as a temporary effect)
          }
        });
      }

      // Remove the chem from inventory
      newState.inventory[chemIndex].quantity -= 1;
      if (newState.inventory[chemIndex].quantity === 0) {
        newState.inventory.splice(chemIndex, 1);
      }

      return newState;
    });
  };

  const startRecruitment = (): boolean => {
    const recruitmentModuleIndex = gameState.baseModules.findIndex(module => module.id === 'recruitment-radio');
    if (recruitmentModuleIndex === -1 || !gameState.baseModules[recruitmentModuleIndex].isActive) return false;

    const cost = 150 + (gameState.squad.length * 50);
    if (gameState.caps < cost) return false;
    if (Date.now() < gameState.recruitmentCooldown) return false;

    setGameState(prev => {
      const newModules = [...prev.baseModules];
      newModules[recruitmentModuleIndex] = { ...newModules[recruitmentModuleIndex], recruitmentActive: true };

      return {
        ...prev,
        caps: prev.caps - cost,
        baseModules: newModules,
        recruitmentCooldown: Date.now() + (5 * 60 * 1000) // 5 minutes
      };
    });

    return true;
  };

  const getModuleDetails = (moduleId: string) => {
    return gameState.baseModules.find(module => module.id === moduleId);
  };

  const addNotification = (notification: Omit<GameNotification, 'timestamp' | 'isRead'>) => {
    setGameState(prev => ({
      ...prev,
      pendingNotifications: [...prev.pendingNotifications, { ...notification, timestamp: Date.now(), isRead: false }]
    }));
  };

  const markNotificationAsRead = (notificationId: string) => {
    setGameState(prev => ({
      ...prev,
      pendingNotifications: prev.pendingNotifications.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
    }));
  };

  const clearNotifications = () => {
    setGameState(prev => ({
      ...prev,
      pendingNotifications: []
    }));
  };

  const dismissNotification = (notificationId: string) => {
    setGameState(prev => ({
      ...prev,
      pendingNotifications: prev.pendingNotifications.filter(n => n.id !== notificationId)
    }));
  };

  const handleDialogueChoice = (notificationId: string, choiceIndex: number) => {
    const notification = gameState.pendingNotifications.find(n => n.id === notificationId);
    if (notification?.dialogueOptions && notification.dialogueOptions[choiceIndex]) {
      const choice = notification.dialogueOptions[choiceIndex];
      
      // Apply outcome
      if (choice.outcome.caps) {
        addCurrency('caps', choice.outcome.caps);
      }
      if (choice.outcome.items) {
        choice.outcome.items.forEach(itemId => {
          const item = GAME_ITEMS.find(i => i.id === itemId);
          if (item) {
            addItem({ ...item, quantity: 1 });
          }
        });
      }
    }
    
    dismissNotification(notificationId);
  };

  const handleEventChoice = (eventId: string, choiceIndex: number) => {
    setGameState(prev => {
      const eventIndex = prev.activeEvents.findIndex(e => e.id === eventId);
      if (eventIndex === -1) return prev;

      const event = prev.activeEvents[eventIndex];
      const choice = event.choices[choiceIndex];

      // Apply choice outcome
      let newState = { ...prev };
      if (choice.outcome) {
        if (choice.outcome.caps) {
          newState.caps += choice.outcome.caps;
        }
        if (choice.outcome.items) {
          choice.outcome.items.forEach((itemId: string) => {
            const item = GAME_ITEMS.find(i => i.id === itemId);
            if (item) {
              const existingIndex = newState.inventory.findIndex(inv => inv.id === itemId);
              if (existingIndex >= 0) {
                newState.inventory[existingIndex].quantity += 1;
              } else {
                newState.inventory.push({ ...item, quantity: 1 });
              }
            }
          });
        }
      }

      // Remove event from active events
      newState.activeEvents = newState.activeEvents.filter(e => e.id !== eventId);
      
      // Add to encounter history
      newState.encounterHistory.push({
        ...event,
        responded: true,
        outcome: choice.text
      });

      return newState;
    });
  };

  const addTerminalEntry = (entry: Omit<TerminalEntry, 'timestamp'>) => {
    setGameState(prev => ({
      ...prev,
      terminalEntries: [...prev.terminalEntries, { ...entry, timestamp: Date.now() }]
    }));
  };

  const abortMission = (missionId: string) => {
    setGameState(prev => {
      const mission = prev.activeMissions.find(m => m.id === missionId);
      if (!mission) return prev;

      // Return squad members to available status
      const newSquad = prev.squad.map(member => 
        mission.assignedSquad.includes(member.id) 
          ? { ...member, status: 'available' as const }
          : member
      );

      return {
        ...prev,
        activeMissions: prev.activeMissions.filter(m => m.id !== missionId),
        squad: newSquad
      };
    });
  };

  const respondToEncounter = (encounterId: string, choiceIndex: number) => {
    setGameState(prev => {
      const encounter = prev.encounterHistory.find(e => e.id === encounterId);
      if (!encounter || !encounter.dialogueOptions) return prev;

      const option = encounter.dialogueOptions[choiceIndex];
      if (!option) return prev;

      // Apply the outcome
      let newState = { ...prev };
      if (option.outcome.caps) {
        newState.caps += option.outcome.caps;
      }
      if (option.outcome.items) {
        option.outcome.items.forEach(itemId => {
          const item = GAME_ITEMS.find(i => i.id === itemId);
          if (item) {
            const existingIndex = newState.inventory.findIndex(inv => inv.id === itemId);
            if (existingIndex >= 0) {
              newState.inventory[existingIndex].quantity += 1;
            } else {
              newState.inventory.push({ ...item, quantity: 1 });
            }
          }
        });
      }

      // Mark encounter as responded
      newState.encounterHistory = newState.encounterHistory.map(e =>
        e.id === encounterId ? { ...e, responded: true, outcome: option.text } : e
      );

      return newState;
    });
  };

  const manageFusionCores = (action: 'add' | 'remove' | 'activate' | 'deactivate', coreId?: string) => {
    setGameState(prev => {
      let newCores = [...prev.fusionCores];
      
      switch (action) {
        case 'add':
          const newCore: FusionCore = {
            id: uuidv4(),
            currentCharge: 100,
            maxCharge: 100,
            isActive: true,
            efficiency: 100
          };
          newCores.push(newCore);
          break;
          
        case 'remove':
          if (coreId) {
            newCores = newCores.filter(core => core.id !== coreId);
          }
          break;
          
        case 'activate':
          if (coreId) {
            const coreIndex = newCores.findIndex(core => core.id === coreId);
            if (coreIndex >= 0) {
              newCores[coreIndex] = { ...newCores[coreIndex], isActive: true };
            }
          }
          break;
          
        case 'deactivate':
          if (coreId) {
            const coreIndex = newCores.findIndex(core => core.id === coreId);
            if (coreIndex >= 0) {
              newCores[coreIndex] = { ...newCores[coreIndex], isActive: false };
            }
          }
          break;
      }
      
      return { ...prev, fusionCores: newCores };
    });
  };

  const addFusionCore = (stationId: string) => {
    manageFusionCores('add');
  };

  const removeFusionCore = (stationId: string, coreId: string) => {
    manageFusionCores('remove', coreId);
  };

  const refreshTrading = () => {
    setGameState(prev => {
      const tradingItems: TradeItem[] = GAME_ITEMS
        .filter(() => Math.random() < 0.3)
        .slice(0, 8)
        .map(item => ({
          ...item,
          quantity: Math.floor(Math.random() * 5) + 1,
          price: Math.floor(item.value * (0.8 + Math.random() * 0.4)),
          currency: 'caps' as const,
          stock: Math.floor(Math.random() * 10) + 1,
          category: item.type
        }));

      return {
        ...prev,
        tradingInventory: tradingItems,
        lastTradeRefresh: Date.now()
      };
    });
  };

  const refreshTradingInventory = () => {
    refreshTrading();
  };

  const generateInitialSquad = (): SquadMember[] => {
    const initialSquad: SquadMember[] = [
      {
        id: 'initial-member-1',
        name: 'Jake Morrison',
        level: 1,
        experience: 0,
        specialization: 'combat',
        status: 'available',
        stats: {
          health: 100,
          maxHealth: 100,
          combat: 8,
          stealth: 4,
          tech: 3,
          charisma: 5,
          hunger: 80,
          thirst: 75
        },
        equipment: { weapon: '', armor: '', accessory: '' },
        inventory: [],
        traits: ['Experienced Fighter']
      },
      {
        id: 'initial-member-2',
        name: 'Sarah Chen',
        level: 1,
        experience: 0,
        specialization: 'tech',
        status: 'available',
        stats: {
          health: 85,
          maxHealth: 85,
          combat: 4,
          stealth: 6,
          tech: 9,
          charisma: 6,
          hunger: 85,
          thirst: 80
        },
        equipment: { weapon: '', armor: '', accessory: '' },
        inventory: [],
        traits: ['Tech Savvy']
      }
    ];

    setGameState(prev => ({ ...prev, squad: initialSquad }));
    return initialSquad;
  };

  // Calculate base energy properly
  const calculateBaseEnergy = () => {
    const totalGeneration = gameState.fusionCores
      .filter(core => core.isActive && core.currentCharge > 0)
      .reduce((sum, core) => sum + (core.efficiency / 5), 0);

    const totalConsumption = gameState.baseModules
      .filter(module => module.isActive)
      .reduce((sum, module) => sum + (module.energyCost || 0), 0);

    return Math.max(0, Math.min(gameState.maxBaseEnergy, totalGeneration - totalConsumption));
  };

  // Update base energy periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setGameState(prev => ({
        ...prev,
        baseEnergy: calculateBaseEnergy()
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, [gameState.fusionCores, gameState.baseModules]);

  // Provide the game state and functions
  return (
    <GameContext.Provider value={{
      gameState,
      login,
      logout,
      addCurrency,
      spendCurrency,
      useConsumable,
      removeItem,
      addItem,
      buyItem,
      sellItem,
      startMission,
      completeMission,
      addExperience,
      upgradeModule,
      toggleModule,
      equipItem,
      updateSettings,
      updateUISettings,
      transferItemToSquad,
      useChem,
      startRecruitment,
      getModuleDetails,
      addNotification,
      markNotificationAsRead,
      clearNotifications,
      addTerminalEntry,
      abortMission,
      respondToEncounter,
      manageFusionCores,
      addFusionCore,
      removeFusionCore,
      refreshTrading,
      dismissNotification,
      handleDialogueChoice,
      handleEventChoice
    }}>
      {children}
    </GameContext.Provider>
  );
};

// Hook for using the game context
const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

export { GameProvider, useGame };
