
import React, { useState, useEffect } from 'react';
import { Navigation } from '@/components/Navigation';
import { BaseHub } from '@/components/base/BaseHub';
import { TradingPost } from '@/components/trading/TradingPost';
import { Inventory } from '@/components/inventory/Inventory';
import { Combat } from '@/components/combat/Combat';
import { Operations } from '@/components/operations/Operations';
import { Settings } from '@/components/settings/Settings';
import { SquadManagement } from '@/components/squad/SquadManagement';
import { Status } from '@/components/status/Status';
import { Terminal } from '@/components/terminal/Terminal';
import { NotificationSystem } from '@/components/notifications/NotificationSystem';
import { LoginScreen } from '@/components/auth/LoginScreen';
import { GameProvider, useGame } from '@/context/GameContext';

const GameContent = () => {
  const [activeSection, setActiveSection] = useState('base');
  const { gameState } = useGame();
  const [currentBaseEnergy, setCurrentBaseEnergy] = useState(gameState.baseEnergy);

  // Show login screen if not logged in
  if (!gameState.isLoggedIn) {
    return <LoginScreen />;
  }

  // Calculate real-time base energy
  useEffect(() => {
    const calculateRealTimeEnergy = () => {
      const totalGeneration = gameState.fusionCores
        .filter(core => core.isActive && core.currentCharge > 0)
        .reduce((sum, core) => sum + (core.efficiency / 5), 0);

      const totalConsumption = gameState.baseModules
        .filter(module => module.isActive)
        .reduce((sum, module) => sum + (module.energyCost || 0), 0);

      const netEnergy = Math.max(0, Math.min(gameState.maxBaseEnergy, totalGeneration - totalConsumption));
      setCurrentBaseEnergy(netEnergy);
    };

    calculateRealTimeEnergy();
    const interval = setInterval(calculateRealTimeEnergy, 1000);
    return () => clearInterval(interval);
  }, [gameState.fusionCores, gameState.baseModules, gameState.maxBaseEnergy]);

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'base':
        return <BaseHub />;
      case 'trading':
        return <TradingPost />;
      case 'inventory':
        return <Inventory />;
      case 'combat':
        return <Combat />;
      case 'operations':
        return <Operations />;
      case 'squad':
        return <SquadManagement />;
      case 'status':
        return <Status />;
      case 'terminal':
        return <Terminal />;
      case 'settings':
        return <Settings />;
      default:
        return <BaseHub />;
    }
  };

  const getContentPadding = () => {
    if (gameState.uiSettings.buttonPosition === 'bottom') {
      return 'pb-24';
    }
    return '';
  };

  return (
    <div 
      className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-amber-900 text-white relative"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.8)), url('${gameState.customBackgrounds.main}')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="max-w-md mx-auto min-h-screen flex flex-col">
        {/* Navigation */}
        {gameState.uiSettings.buttonPosition !== 'bottom' && (
          <Navigation activeSection={activeSection} setActiveSection={setActiveSection} />
        )}
        
        {/* Header with Resources */}
        <div className="bg-black/40 backdrop-blur-sm border-b border-amber-500/30 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center">
                <span className="text-black font-bold text-sm">FS</span>
              </div>
              <div>
                <h1 className="text-lg font-bold text-amber-400">Fallout: Scrapline</h1>
                <p className="text-xs text-gray-400">
                  Commander {gameState.username} • Level {gameState.commanderLevel}
                  <span className="ml-2">XP: {gameState.commanderExperience}/{gameState.commanderLevel * 100}</span>
                </p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="text-center">
                <p className="text-gray-400">Caps</p>
                <p className="text-amber-400 font-bold">{gameState.caps}</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400">Scrip</p>
                <p className="text-blue-400 font-bold">{gameState.scrip}</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400">Fuel</p>
                <p className="text-purple-400 font-bold">{gameState.nuclearFuel}</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400">Food</p>
                <p className="text-green-400 font-bold">{gameState.food}</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400">Water</p>
                <p className="text-cyan-400 font-bold">{gameState.water}</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400">Tech</p>
                <p className="text-orange-400 font-bold">{gameState.techFrags}</p>
              </div>
            </div>
          </div>

          {/* Fixed Live Energy Bar */}
          <div className="mb-2">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-gray-400">Base Power</span>
              <span className="text-yellow-400">{currentBaseEnergy.toFixed(1)}/{gameState.maxBaseEnergy}</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-1000 ${
                  currentBaseEnergy > gameState.maxBaseEnergy * 0.7 ? 'bg-green-500' :
                  currentBaseEnergy > gameState.maxBaseEnergy * 0.3 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${(currentBaseEnergy / gameState.maxBaseEnergy) * 100}%` }}
              />
            </div>
          </div>

          {/* Fusion Core Status */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <p className="text-gray-400">Active Cores</p>
              <p className="text-green-400 font-bold">
                {gameState.fusionCores.filter(core => core.isActive).length}/{gameState.fusionCores.length}
              </p>
            </div>
            <div>
              <p className="text-gray-400">Total Charge</p>
              <p className="text-blue-400 font-bold">
                {Math.floor(gameState.fusionCores.reduce((sum, core) => sum + core.currentCharge, 0))}
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className={`flex-1 overflow-y-auto ${getContentPadding()}`}>
          {renderActiveSection()}
        </div>

        {/* Bottom Navigation */}
        {gameState.uiSettings.buttonPosition === 'bottom' && (
          <Navigation activeSection={activeSection} setActiveSection={setActiveSection} />
        )}
      </div>

      {/* Notification System */}
      <NotificationSystem />
    </div>
  );
};

const Index = () => {
  return (
    <GameProvider>
      <GameContent />
    </GameProvider>
  );
};

export default Index;
