
export interface GameItem {
  id: string;
  name: string;
  type: 'weapon' | 'armor' | 'consumable' | 'material' | 'chem' | 'fuel' | 'special';
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary';
  description: string;
  value: number;
  weight: number;
  icon: string;
  function?: string;
  stats?: { [key: string]: number };
  effects?: { [key: string]: number };
}

export const GAME_ITEMS: GameItem[] = [
  // Weapons
  {
    id: 'pipe-rifle',
    name: 'Pipe Rifle',
    type: 'weapon',
    rarity: 'common',
    description: 'A makeshift rifle cobbled together from scrap metal and pipe.',
    value: 75,
    weight: 6,
    icon: '🔫',
    function: 'Provides basic ranged combat capability',
    stats: { damage: 15, accuracy: 65 }
  },
  {
    id: 'combat-knife',
    name: 'Combat Knife',
    type: 'weapon',
    rarity: 'common',
    description: 'A sharp, reliable blade for close quarters combat.',
    value: 25,
    weight: 1,
    icon: '🔪',
    function: 'Silent melee weapon with high accuracy',
    stats: { damage: 12, accuracy: 85 }
  },
  {
    id: 'laser-rifle',
    name: 'Laser Rifle',
    type: 'weapon',
    rarity: 'rare',
    description: 'Pre-war energy weapon that fires concentrated laser beams.',
    value: 450,
    weight: 8,
    icon: '⚡',
    function: 'High-tech energy weapon with no ammo requirements',
    stats: { damage: 35, accuracy: 80 }
  },

  // Armor
  {
    id: 'leather-armor',
    name: 'Leather Armor',
    type: 'armor',
    rarity: 'common',
    description: 'Basic protection made from tanned animal hide.',
    value: 50,
    weight: 8,
    icon: '🦺',
    function: 'Provides basic protection against physical damage',
    stats: { defense: 10, durability: 100 }
  },
  {
    id: 'combat-armor',
    name: 'Combat Armor',
    type: 'armor',
    rarity: 'uncommon',
    description: 'Military-grade protective gear designed for combat situations.',
    value: 200,
    weight: 15,
    icon: '🛡️',
    function: 'Advanced protection with radiation resistance',
    stats: { defense: 25, durability: 150, radResist: 15 }
  },
  {
    id: 'power-armor',
    name: 'T-45 Power Armor',
    type: 'armor',
    rarity: 'legendary',
    description: 'Pre-war powered exoskeleton providing ultimate protection.',
    value: 2500,
    weight: 50,
    icon: '🤖',
    function: 'Ultimate protection with strength enhancement',
    stats: { defense: 75, durability: 500, strength: 10 }
  },

  // Consumables
  {
    id: 'stimpak',
    name: 'Stimpak',
    type: 'consumable',
    rarity: 'common',
    description: 'Auto-injector containing healing compounds.',
    value: 25,
    weight: 0.5,
    icon: '💉',
    function: 'Instantly restores 50 health points',
    effects: { health: 50 }
  },
  {
    id: 'rad-away',
    name: 'Rad-Away',
    type: 'consumable',
    rarity: 'uncommon',
    description: 'Intravenous radiation treatment.',
    value: 40,
    weight: 0.5,
    icon: '🧪',
    function: 'Removes radiation poisoning from the body',
    effects: { radiation: -100 }
  },
  {
    id: 'nuka-cola',
    name: 'Nuka-Cola',
    type: 'consumable',
    rarity: 'common',
    description: 'The beverage that won the west! Restores thirst.',
    value: 15,
    weight: 1,
    icon: '🥤',
    function: 'Restores thirst and provides small health boost',
    effects: { thirst: 25, health: 5 }
  },

  // Chems
  {
    id: 'psycho',
    name: 'Psycho',
    type: 'chem',
    rarity: 'uncommon',
    description: 'Military combat drug that enhances damage resistance.',
    value: 75,
    weight: 0.1,
    icon: '💊',
    function: 'Increases damage resistance and combat effectiveness',
    effects: { damage: 25, defense: 15 }
  },
  {
    id: 'jet',
    name: 'Jet',
    type: 'chem',
    rarity: 'common',
    description: 'Highly addictive stimulant that slows time perception.',
    value: 50,
    weight: 0.1,
    icon: '🌪️',
    function: 'Increases action points and reaction speed',
    effects: { stealth: 20, accuracy: 15 }
  },

  // Materials
  {
    id: 'steel',
    name: 'Steel',
    type: 'material',
    rarity: 'common',
    description: 'Salvaged steel from pre-war structures.',
    value: 3,
    weight: 1,
    icon: '🔩',
    function: 'Essential crafting material for weapons and structures'
  },
  {
    id: 'circuitry',
    name: 'Circuitry',
    type: 'material',
    rarity: 'uncommon',
    description: 'Complex electronic components from old world tech.',
    value: 15,
    weight: 0.5,
    icon: '🔌',
    function: 'Required for advanced electronic devices and upgrades'
  },
  {
    id: 'rare-component',
    name: 'Rare Component',
    type: 'material',
    rarity: 'rare',
    description: 'Highly advanced pre-war technology component.',
    value: 100,
    weight: 0.5,
    icon: '⚙️',
    function: 'Used in high-tier equipment upgrades and power systems'
  },

  // Fuel
  {
    id: 'fusion-core',
    name: 'Fusion Core',
    type: 'fuel',
    rarity: 'rare',
    description: 'Pre-war fusion battery providing massive energy output.',
    value: 300,
    weight: 3,
    icon: '🔋',
    function: 'Powers fusion reactors and heavy equipment for extended periods'
  },
  {
    id: 'energy-cell',
    name: 'Energy Cell',
    type: 'fuel',
    rarity: 'common',
    description: 'Small battery for energy weapons.',
    value: 8,
    weight: 0.1,
    icon: '🔋',
    function: 'Ammunition for laser and plasma weapons'
  },

  // Special Items
  {
    id: 'holotape',
    name: 'Holotape',
    type: 'special',
    rarity: 'uncommon',
    description: 'Data storage device containing valuable information.',
    value: 25,
    weight: 0.1,
    icon: '💾',
    function: 'Contains quest information, terminal access codes, or valuable data'
  },
  {
    id: 'pre-war-money',
    name: 'Pre-War Money',
    type: 'special',
    rarity: 'common',
    description: 'Currency from before the Great War, now mostly worthless.',
    value: 1,
    weight: 0.1,
    icon: '💵',
    function: 'Can be used as cloth material or traded to collectors'
  }
];
